package com.spring.onlineBicycle.repositories;

import com.spring.onlineBicycle.models.CompanyImage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CompanyRepository extends JpaRepository<CompanyImage, Long> {
}
