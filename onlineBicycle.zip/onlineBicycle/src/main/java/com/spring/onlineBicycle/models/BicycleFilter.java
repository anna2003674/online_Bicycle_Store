package com.spring.onlineBicycle.models;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class BicycleFilter {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name="minPrice")
    private Double minPrice;

    @Column(name="maxPrice")
    private Double maxPrice;

    @Column(name="brand")
    private String brand;

    @Column(name="wheelDiameter")
    private String wheelDiameter;

    @Column(name="year")
    private int year;

    @Column(name="numberSpeeds")
    private int numberSpeeds;

    @Column(name="type")
    private String type;

    @Column(name="weight")
    private String weight; // вес

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getMinPrice() {
        return minPrice;
    }

    public void setMinPrice(Double minPrice) {
        this.minPrice = minPrice;
    }

    public Double getMaxPrice() {
        return maxPrice;
    }

    public void setMaxPrice(Double maxPrice) {
        this.maxPrice = maxPrice;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getWheelDiameter() {
        return wheelDiameter;
    }

    public void setWheelDiameter(String wheelDiameter) {
        this.wheelDiameter = wheelDiameter;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getNumberSpeeds() {
        return numberSpeeds;
    }

    public void setNumberSpeeds(int numberSpeeds) {
        this.numberSpeeds = numberSpeeds;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }
}
