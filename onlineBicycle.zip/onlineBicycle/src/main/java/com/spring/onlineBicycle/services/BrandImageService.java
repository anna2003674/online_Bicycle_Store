package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.BrandImage;
import com.spring.onlineBicycle.repositories.BrandImageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BrandImageService {

    private final BrandImageRepository brandImageRepository;

    @Autowired
    public BrandImageService(BrandImageRepository brandImageRepository) {
        this.brandImageRepository = brandImageRepository;
    }

    public void saveBrandImage(byte[] imageData) {
        BrandImage brandImage = new BrandImage();
        brandImage.setImageData(imageData);
        brandImageRepository.save(brandImage);
    }

    public List<BrandImage> getAllBrandImages() {
        return brandImageRepository.findAll();
    }

    public BrandImage getBrandImageById(Long id) {
        return brandImageRepository.findById(id).orElse(null);
    }


}