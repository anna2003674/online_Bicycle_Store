package com.spring.onlineBicycle.models;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class DeliveryImage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] imageData;

    public Long getId() {
        return id;
    }

    public DeliveryImage() {
    }

    public void setId(Long id) {
        this.id = id;
    }

    public byte[] getImageData() {
        return imageData;
    }

    public void setImageData(byte[] imageData) {
        this.imageData = imageData;
    }
}
