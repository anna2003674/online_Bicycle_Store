package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.BrandImage;
import com.spring.onlineBicycle.repositories.BrandImageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
class BrandImageService {
    private final BrandImageRepository brandImageRepository;

    @Autowired
    public BrandImageService(BrandImageRepository brandImageRepository) {
        this.brandImageRepository = brandImageRepository;
    }

    public void saveBrandImage(byte[] imageData) {
        BrandImage brandImage = new BrandImage();
        brandImage.setImageData(imageData);
        brandImageRepository.save(brandImage);
    }

    public byte[] getBrandImageById(Long id) {
        Optional<BrandImage> brandImageOptional = brandImageRepository.findById(id);
        return brandImageOptional.map(BrandImage::getImageData).orElse(null);
    }
}