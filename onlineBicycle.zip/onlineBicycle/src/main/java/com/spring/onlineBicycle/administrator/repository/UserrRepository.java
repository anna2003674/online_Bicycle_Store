package com.spring.onlineBicycle.administrator.repository;

import com.spring.onlineBicycle.administrator.models.User;
import org.springframework.data.repository.CrudRepository;


public interface UserrRepository extends CrudRepository<User, Integer> {



}
