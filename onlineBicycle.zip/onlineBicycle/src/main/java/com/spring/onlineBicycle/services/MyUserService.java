package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.MyUser;
import com.spring.onlineBicycle.repositories.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MyUserService {

    private final UserRepository userRepository;

    public MyUserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public List<MyUser> getAllUsers() {
        return userRepository.findAll();
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
}
