package com.spring.onlineBicycle.repositories;

import com.spring.onlineBicycle.services.User;
import org.springframework.data.repository.CrudRepository;


public interface UserrRepository extends CrudRepository<User, Integer> {
}
