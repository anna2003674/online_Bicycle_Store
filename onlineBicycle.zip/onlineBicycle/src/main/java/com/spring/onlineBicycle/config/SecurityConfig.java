package com.spring.onlineBicycle.config;

import com.spring.onlineBicycle.services.MyUserDetailsService;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.web.filter.HiddenHttpMethodFilter;
import java.io.IOException;
import java.util.Collection;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
    @Bean
    public UserDetailsService userDetailsService() {
        return new MyUserDetailsService();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http
                .csrf().disable()
                .authorizeRequests(auth -> auth
                        .requestMatchers("/api/v1/users/register", "/register", "/login").permitAll()
                        // Для администратора
                        .requestMatchers("/administrator/**", "/login","/administrator/users/**","/administrator/users/*/**").authenticated()
                        // Для менеджера по велосипедам
                        .requestMatchers("/bicycleManager/**", "/login").authenticated()
                        // Для менеджера по заказам
                        .requestMatchers("/orderManager/**", "/login").authenticated()
                        // Для user-a
                        .requestMatchers("/users/**", "/login").authenticated()
                        // Для незарегистрированных пользователей
                        .requestMatchers("/welcome", "/api/v1/users/register", "/register", "/", "/deliveryPayment",
                                "/contact", "/brands", "/cataloge", "/about", "/home", "/login").permitAll()
                        // Для зарегистрированных пользователей
                        .requestMatchers("/api/v1/apps/**", "/administrator/**", "/bicycleManager/**",
                                "/bicycleManager/add", "/bicycleManager/home", "/bicycleManager/home/**",
                                "/bicycleManager/home/*/edit", "/bicycleManager/home/*/remove", "/login", "/orderManager/**","/users/**",
                                "/administrator/users/**","/administrator/**","/administrator/users/*/**").authenticated()
                        .requestMatchers(HttpMethod.DELETE, "/administrator/users/**").hasAuthority("ROLE_ADMIN")
                )
                .formLogin(formLogin -> formLogin
                        .permitAll()
                        .successHandler(authenticationSuccessHandler())
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/home")
                        .invalidateHttpSession(true)
                        .deleteCookies("JSESSIONID"))
                .build();
    }

    @Bean
    public AuthenticationSuccessHandler authenticationSuccessHandler() {
        return new AuthenticationSuccessHandler() {
            @Override
            public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
                Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
                for (GrantedAuthority authority : authorities) {
                    if (authority.getAuthority().equals("ROLE_ADMIN")) {
                        response.sendRedirect("/administrator/home");
                        return;
                    } else if (authority.getAuthority().equals("ROLE_BICYCLEMANAGER")) {
                        response.sendRedirect("/bicycleManager/home");
                        return;
                    } else if (authority.getAuthority().equals("ROLE_ORDERMANAGER")) {
                        response.sendRedirect("/orderManager/home");
                        return;
                    } else if (authority.getAuthority().equals("ROLE_USER")) {
                        response.sendRedirect("/users/home");
                        return;
                    }
                }
                response.sendRedirect("/home");
            }
        };
    }

    @Bean
    public HiddenHttpMethodFilter hiddenHttpMethodFilter() {
        return new HiddenHttpMethodFilter();
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService());
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();

    }
}








