package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.MyUser;
import com.spring.onlineBicycle.services.UserService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/users")
@AllArgsConstructor
public class UserController {

    private final UserService userService;

    // форма регистрации только с name, password
//    @PostMapping("/register")
//    public String registerUser(@RequestBody MyUser user) {
//        userService.saveUser(user);
//        return "User registered successfully!";
//    }

//    @PostMapping("/register")
//    public ResponseEntity<String> registerUser(@RequestBody MyUser form) {
//        MyUser newUser = new MyUser();
//        newUser.setName(form.getName());
//        newUser.setPassword(form.getPassword());
//        newUser.setSurname(form.getSurname());
//        newUser.setEmail(form.getEmail());
//        newUser.setPatronymic(form.getPatronymic());
//        userService.saveUser(newUser);
//        return ResponseEntity.ok("User registered successfully!");
//    }


    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody MyUser formData) {
        userService.saveUser(formData);
        return ResponseEntity.ok("User registered successfully!");
    }
}