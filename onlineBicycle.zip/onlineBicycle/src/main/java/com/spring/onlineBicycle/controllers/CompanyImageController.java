package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.services.CompanyImageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class CompanyImageController {

    private final CompanyImageService companyImageService;

    @Autowired
    public CompanyImageController(CompanyImageService companyImageService) {
        this.companyImageService = companyImageService;
    }

    @PostMapping("/upload4")
    @ResponseBody
    public HttpStatus uploadCompanyImage(@RequestParam("image") MultipartFile image) {
        try {
            byte[] imageData = image.getBytes();
            companyImageService.saveCompanyImage(imageData);
            return HttpStatus.CREATED;
        } catch (Exception e) {
            e.printStackTrace();
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }
    }
}
