package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.Purchase;
import com.spring.onlineBicycle.repositories.PurchaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PurchaseService {

    private final PurchaseRepository orderRepository;

    @Autowired
    public PurchaseService(PurchaseRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public void createOrder(Purchase order) {
        orderRepository.save(order);
    }

    public List<Purchase> getOrdersByUsername(String username) {
        return orderRepository.findByCustomerName(username);
    }

    public List<Purchase> getAllOrders() {
        return orderRepository.findAll();
    }


    public Purchase getOrderById(Long orderId) {
        Optional<Purchase> order = orderRepository.findById(orderId);
        return order.orElse(null);
    }

    public void updateOrder(Purchase order) {
        orderRepository.save(order);
    }

}