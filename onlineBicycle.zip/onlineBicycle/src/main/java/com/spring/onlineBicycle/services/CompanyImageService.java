package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.CompanyImage;
import com.spring.onlineBicycle.repositories.CompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CompanyImageService {

    private final CompanyRepository companyRepository;

    @Autowired
    public CompanyImageService(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

    public void saveCompanyImage(byte[] imageData) {
        CompanyImage companyImage = new CompanyImage();
        companyImage.setImageData(imageData);
        companyRepository.save(companyImage);
    }

    public List<CompanyImage> getAllCompanyImages() {
        return companyRepository.findAll();
    }

    public CompanyImage getCompanyImageById(Long id) {
        return companyRepository.findById(id).orElse(null);
    }
}
