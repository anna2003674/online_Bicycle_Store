package com.spring.onlineBicycle.repositories;

import com.spring.onlineBicycle.models.BrandImage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BrandImageRepository extends JpaRepository<BrandImage, Long> {
}
