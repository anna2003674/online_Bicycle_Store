package com.spring.onlineBicycle.models;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "users")
@NoArgsConstructor
public class MyUser {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true)
    private String name; // какой-то код-имя для входа
    private String password;
    private String roles;

    @Column(name="surname")
    private String surname; // фамилия

    @Column(name="email")
    private String email;

    @Column(name="patronymic")
    private String patronymic; // отчество

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] imageData;

    public byte[] getImageData() {
        return imageData;
    }

    public void setImageData(byte[] imageData) {
        this.imageData = imageData;
    }

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ShoppingCartItem> shoppingCartItems = new ArrayList<>();


//    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    @OneToMany(mappedBy = "user")
    private List<Favorite> favorites;

    public MyUser(String name, String password, String roles) {
        this.name = name;
        this.password = password;
        this.roles = roles;
    }

    public MyUser(String name, String password, String roles, List<ShoppingCartItem> shoppingCartItems) {
        this.name = name;
        this.password = password;
        this.roles = roles;
        this.shoppingCartItems = shoppingCartItems;
    }

    public MyUser(Long id, String name, String password, String roles, byte[] imageData, List<ShoppingCartItem> shoppingCartItems, List<Favorite> favorites) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.roles = roles;
        this.imageData = imageData;
        this.shoppingCartItems = shoppingCartItems;
        this.favorites = favorites;
    }

    public MyUser(Long id, String name, String password, String roles, byte[] imageData) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.roles = roles;
        this.imageData = imageData;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRoles() {
        return roles;
    }

    public void setRoles(String roles) {
        this.roles = roles;
    }

    public List<ShoppingCartItem> getShoppingCartItems() {
        return shoppingCartItems;
    }

    public void setShoppingCartItems(List<ShoppingCartItem> shoppingCartItems) {
        this.shoppingCartItems = shoppingCartItems;
    }

    public List<Favorite> getFavorites() {
        return favorites;
    }

    public void setFavorites(List<Favorite> favorites) {
        this.favorites = favorites;
    }


    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public void setPatronymic(String patronymic) {
        this.patronymic = patronymic;
    }

    public MyUser(Long id, String name, String password, String roles, String surname, String email, String patronymic, byte[] imageData, List<ShoppingCartItem> shoppingCartItems, List<Favorite> favorites) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.roles = roles;
        this.surname = surname;
        this.email = email;
        this.patronymic = patronymic;
        this.imageData = imageData;
        this.shoppingCartItems = shoppingCartItems;
        this.favorites = favorites;
    }






    public MyUser(Long id, String name, String password, String surname, String email, String patronymic) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.surname = surname;
        this.email = email;
        this.patronymic = patronymic;
    }

    public MyUser(String name, String password, String surname, String email, String patronymic, String roles) {
        this.name = name;
        this.password = password;
        this.surname = surname;
        this.email = email;
        this.patronymic = patronymic;
        this.roles = roles;
    }
}
