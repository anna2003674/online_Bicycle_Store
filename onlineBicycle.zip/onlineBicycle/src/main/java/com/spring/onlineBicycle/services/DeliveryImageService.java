package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.BrandImage;
import com.spring.onlineBicycle.models.DeliveryImage;
import com.spring.onlineBicycle.repositories.BrandImageRepository;
import com.spring.onlineBicycle.repositories.DeliveryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeliveryImageService {

    private final DeliveryRepository deliveryRepository;


    @Autowired
    public DeliveryImageService(DeliveryRepository deliveryRepository) {
        this.deliveryRepository = deliveryRepository;
    }


    public void saveDeliveryImage(byte[] imageData) {
        DeliveryImage deliveryImage = new DeliveryImage();
        deliveryImage.setImageData(imageData);
        deliveryRepository.save(deliveryImage);
    }

    public List<DeliveryImage> getAllDeliveryImages() {
        return deliveryRepository.findAll();
    }

    public DeliveryImage getDeliveryImageById(Long id) {
        return deliveryRepository.findById(id).orElse(null);
    }


}