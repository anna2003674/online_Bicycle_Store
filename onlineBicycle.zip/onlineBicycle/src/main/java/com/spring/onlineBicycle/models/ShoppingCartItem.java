package com.spring.onlineBicycle.models;

import jakarta.persistence.*;

@Entity
public class ShoppingCartItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Bicycle bicycle;

    // добавили username
    private String username;


    private int quantity;

    public ShoppingCartItem() {
    }

    public ShoppingCartItem(Bicycle bicycle, int quantity) {
        this.bicycle = bicycle;
        this.quantity = quantity;
    }

    public ShoppingCartItem(Bicycle bicycle, int quantity,String username) {
        this.bicycle = bicycle;
        this.quantity = quantity;
        this.username = username;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Bicycle getBicycle() {
        return bicycle;
    }

    public void setBicycle(Bicycle bicycle) {
        this.bicycle = bicycle;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}