package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.Favorite;
import com.spring.onlineBicycle.repositories.FavoriteRepository;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class FavoriteService {

    private final FavoriteRepository favoriteRepository;

    public FavoriteService(FavoriteRepository favoriteRepository) {
        this.favoriteRepository = favoriteRepository;
    }

    public void addToFavorites(Favorite favorite) {
        favoriteRepository.save(favorite);
    }

    public List<Favorite> getFavoritesByUsername(String username) {
        return favoriteRepository.findByUser_Name(username);
    }

    public void removeFromFavorites(Long favoriteId) {
        favoriteRepository.deleteById(favoriteId);
    }

}