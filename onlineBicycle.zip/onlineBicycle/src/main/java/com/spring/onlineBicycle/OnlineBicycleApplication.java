package com.spring.onlineBicycle;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan("com.spring.onlineBicycle") // Укажите пакет, содержащий ваши компоненты
public class OnlineBicycleApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineBicycleApplication.class, args);
	}

}
