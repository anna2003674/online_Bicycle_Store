package com.spring.onlineBicycle;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class OnlineBicycleApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineBicycleApplication.class, args);
	}

}
