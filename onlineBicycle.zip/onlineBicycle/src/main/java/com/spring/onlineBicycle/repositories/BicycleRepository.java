package com.spring.onlineBicycle.repositories;

import com.spring.onlineBicycle.models.Bicycle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BicycleRepository extends JpaRepository<Bicycle, Long> {
    List<Bicycle> findByModellContainingIgnoreCase(String modell);
    List<Bicycle> findByWheelDiameter(double wheelDiameter);
    List<Bicycle> findByWeight(double weight);
}