package com.spring.onlineBicycle.repositories;

import com.spring.onlineBicycle.models.Bicycle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BicycleRepository extends JpaRepository<Bicycle, Long> {


}