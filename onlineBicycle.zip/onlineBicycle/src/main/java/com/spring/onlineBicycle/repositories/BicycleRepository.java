package com.spring.onlineBicycle.repositories;

import com.spring.onlineBicycle.models.Bicycle;
import org.springframework.data.repository.CrudRepository;

public interface BicycleRepository extends CrudRepository<Bicycle, Long> {
}
