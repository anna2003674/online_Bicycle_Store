package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.MyUser;
import com.spring.onlineBicycle.repositories.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
@AllArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final ShoppingCartService shoppingCartService;

    public void saveUser(MyUser user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        MyUser newUser = new MyUser(user.getName(), user.getPassword(), "ROLE_USER");
        userRepository.save(newUser);
    }

    public Optional<MyUser> findByUsername(String username) {
        return userRepository.findByName(username);
    }


    public void deleteUserAndCart(String username) {
        Optional<MyUser> userOptional = userRepository.findByName(username);
        if (userOptional.isPresent()) {
            MyUser user = userOptional.get();
            userRepository.delete(user);
            // Удаляем корзину пользователя
            shoppingCartService.clearCar2(username);
        }
    }

    public void saveUser2(MyUser user) {
        if (!user.getPassword().startsWith("$2a$")) {
            // Пароль еще не захеширован
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        }
        userRepository.save(user);
    }


}