package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.models.BicycleFilter;
import com.spring.onlineBicycle.models.DeliveryImage;
import com.spring.onlineBicycle.models.SliderImage;
import com.spring.onlineBicycle.services.BicycleService;
import com.spring.onlineBicycle.services.DeliveryImageService;
import com.spring.onlineBicycle.services.SliderImageService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/bicycleManager")
@AllArgsConstructor
public class BicycleManager {

    private final BicycleService bicycleService;
    private final DeliveryImageService deliveryImageService;
    private final SliderImageService sliderImageService;

    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String showHomePage(Model model, Principal principal) {
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("sliderImages", sliderImages);
        model.addAttribute("title", "Главная страница сайта");
        model.addAttribute("username", principal.getName());
        return "bicyclemanager/home";
    }

    @GetMapping("/deliveryPayment")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String deliveryPaymentPage(Model model, Principal principal) {
        List<DeliveryImage> deliveryImages = deliveryImageService.getAllDeliveryImages();
        model.addAttribute("deliveryImages", deliveryImages);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "bicyclemanager/deliveryPayment";
    }

    @GetMapping("/catalog")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String catalogGet(Model model, Principal principal) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "bicyclemanager/cataloge";
    }

    @GetMapping("/bicycle")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String getAllBicycles(Model model, Principal principal) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "bicyclemanager/bicycle";
    }

    @PostMapping("/bicycle/delete")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String deleteBicycle(@RequestParam("id") Long id) {
        bicycleService.deleteBicycleById(id);
        return "redirect:/bicycleManager/bicycle";
    }

    @GetMapping("/bicycle/add")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String bicycleAdd(Model model, Principal principal) {
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "bicyclemanager/bicycleAdd";
    }

//    @PostMapping("/bicycle/add")
//    public String addBicycle(@RequestParam("modell") String modell,
//                             @RequestParam("year") int year,
//                             @RequestParam("bottomBracket") String bottomBracket,
//                             @RequestParam("brand") String brand,
//                             @RequestParam("chain") String chain,
//                             @RequestParam("saddle") String saddle,
//                             @RequestParam("pedals") String pedals,
//                             @RequestParam("frontHub") String frontHub,
//                             @RequestParam("type") String type,
//                             @RequestParam("price") double price,
//                             @RequestParam("weight") double weight,
//                             @RequestParam("wheelDiameter") double wheelDiameter,
//                             @RequestParam("frameMaterial") String frameMaterial,
//                             @RequestParam("brakeType") String brakeType,
//                             @RequestParam("numberSpeeds") int numberSpeeds,
//                             @RequestParam("depreciation") String depreciation,
//                             @RequestParam("quantityInStock") int quantityInStock,
//                             @RequestParam("description") String description, Model model) {
//        Bicycle bicycle = new Bicycle(modell, year, bottomBracket, brand, chain, saddle, pedals, frontHub,
//                type, price, weight, wheelDiameter, frameMaterial, brakeType, numberSpeeds, depreciation, quantityInStock, description);
//        bicycleService.addBicycle(bicycle);
//        return "redirect:/bicycleManager/bicycle";
//    }

    @GetMapping("/bicycle/details")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String details(@RequestParam("id") Long id, Model model, Principal principal) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "bicyclemanager/bicycleDetails";
    }

    @GetMapping("/bicycle/edit/{id}")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String update(@PathVariable("id") Long id, Model model, Principal principal) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "bicyclemanager/bicycleEdit";
    }

    @PostMapping("/bicycle/edit")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String updateBicycle(@ModelAttribute("bicycle") Bicycle bicycle,Model model, Principal principal) {
        bicycleService.updateBicycle(bicycle);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "redirect:/bicycleManager/bicycle";
    }

    @GetMapping("/cataloge")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String catalogeBicycle(Model model, Principal principal) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "bicyclemanager/cataloge";
    }

    @PostMapping("/bicycle/search")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String searchBicyclesByModell(@RequestParam("modell") String modell, Model model) {
        List<Bicycle> bicycles = bicycleService.searchBicyclesByModell(modell);
        model.addAttribute("bicycles", bicycles);
        return "bicyclemanager/bicycle";
    }

    @PostMapping("/cataloge/search")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String searchBicyclesCataloge(@RequestParam("modell") String modell, Model model) {
        List<Bicycle> bicycles = bicycleService.searchBicyclesByModell(modell);
        model.addAttribute("bicycles", bicycles);
        return "bicyclemanager/cataloge";
    }

    @PostMapping("/bicycle/add")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String addBicycle(@RequestParam("modell") String modell,
                             @RequestParam("year") int year,
                             @RequestParam("bottomBracket") String bottomBracket,
                             @RequestParam("brand") String brand,
                             @RequestParam("chain") String chain,
                             @RequestParam("saddle") String saddle,
                             @RequestParam("pedals") String pedals,
                             @RequestParam("frontHub") String frontHub,
                             @RequestParam("type") String type,
                             @RequestParam("price") double price,
                             @RequestParam("weight") double weight,
                             @RequestParam("wheelDiameter") double wheelDiameter,
                             @RequestParam("frameMaterial") String frameMaterial,
                             @RequestParam("brakeType") String brakeType,
                             @RequestParam("numberSpeeds") int numberSpeeds,
                             @RequestParam("depreciation") String depreciation,
                             @RequestParam("quantityInStock") int quantityInStock,
                             @RequestParam("description") String description,
                             @RequestParam("image") MultipartFile image, Model model) {
        try {
            byte[] imageData = image.getBytes(); // Получаем массив байтов изображения
            Bicycle bicycle = new Bicycle(modell, year, bottomBracket, brand, chain, saddle, pedals, frontHub,
                    type, price, weight, wheelDiameter, frameMaterial, brakeType, numberSpeeds, depreciation, quantityInStock, description);
            bicycle.setImageData(imageData); // Устанавливаем изображение в объект Bicycle
            bicycleService.addBicycle(bicycle); // Сохраняем велосипед в базе данных
        } catch (IOException e) {
            // Обработка ошибки, если что-то пошло не так при чтении изображения
            e.printStackTrace();
        }
        return "redirect:/bicycleManager/bicycle";
    }

    @GetMapping("/cataloge/{id}")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public ResponseEntity<byte[]> getImageById(@PathVariable("id") Long id) {
        Bicycle bicycle = bicycleService.getBicycleImageById(id);
        if (bicycle != null && bicycle.getImageData() != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_JPEG); // или MediaType.IMAGE_PNG, в зависимости от формата изображения
            return new ResponseEntity<>(bicycle.getImageData(), headers, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/deliveryPayment/{id}")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public ResponseEntity<byte[]> getDeliveryImage(@PathVariable String id) {
        try {
            Long deliveryId = Long.parseLong(id);
            DeliveryImage deliveryImage = deliveryImageService.getDeliveryImageById(deliveryId);
            if (deliveryImage != null && deliveryImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(deliveryImage.getImageData().length);
                return new ResponseEntity<>(deliveryImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }

    @GetMapping("/home/{id}")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public ResponseEntity<byte[]> getSliderImage(@PathVariable String id) {
        try {
            Long sliderId = Long.parseLong(id);
            SliderImage sliderImage = sliderImageService.getSliderImageById(sliderId);
            if (sliderImage != null && sliderImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(sliderImage.getImageData().length);
                return new ResponseEntity<>(sliderImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }

    // фильтр по всем полям
    @PostMapping("/catalog/filter")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String filterBicyclesCatalog(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicycles(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "bicyclemanager/cataloge";
    }

    // фильтр по всем полям
    @GetMapping("/catalog/filter")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String filterBicyclesCatalogGet(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicycles(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "bicyclemanager/cataloge";
    }


    // фильтр по весу
    @PostMapping("/catalog/filterWeigh")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String filterBicyclesCatalogWeigh(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWeigh(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "bicyclemanager/cataloge";
    }

    // фильтр по весу
    @GetMapping("/catalog/filterWeigh")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String filterBicyclesCatalogGetWeigh(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWeigh(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "bicyclemanager/cataloge";
    }


    // фильтр по бренду и количеству скоростей
    @PostMapping("/catalog/filterBrand")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String filterBicyclesCatalogBrand(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesBrands(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "bicyclemanager/cataloge";
    }

    // фильтр по бренду и количеству скоростей
    @GetMapping("/catalog/filterBrand")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String filterBicyclesCatalogGetBrand(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesBrands(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "bicyclemanager/cataloge";
    }


    // фильтр по диаметру колес
    @PostMapping("/catalog/filterWheelDiameter")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String filterBicyclesCatalogWheelDiameter(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWheelDiameter(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "bicyclemanager/cataloge";
    }

    // фильтр по диаметру колес
    @GetMapping("/catalog/filterWheelDiameter")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String filterBicyclesCatalogGetWheelDiameter(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWheelDiameter(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "bicyclemanager/cataloge";
    }

    // личный кабинет
    @GetMapping("/personalArea")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String personalArea(Model model, Principal principal) {
        model.addAttribute("personalArea", "Личный кабинет");
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "bicyclemanager/personal-area";
    }




}
