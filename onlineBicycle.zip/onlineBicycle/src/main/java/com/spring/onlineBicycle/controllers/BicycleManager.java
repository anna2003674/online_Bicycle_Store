package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.services.BicycleService;
import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("/bicycleManager")
@AllArgsConstructor
public class BicycleManager {

    private final BicycleService bicycleService;

    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String showHomePage() {
        return "bicyclemanager/home";
    }

    @GetMapping("/deliveryPayment")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String deliveryPaymentPage() {
        return "bicyclemanager/deliveryPayment";
    }

    @GetMapping("/bicycle")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String getAllBicycles(Model model) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        return "bicyclemanager/bicycle";
    }

    @PostMapping("/bicycle/delete")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String deleteBicycle(@RequestParam("id") Long id) {
        bicycleService.deleteBicycleById(id);
        return "redirect:/bicycleManager/bicycle";
    }

    @GetMapping("/bicycle/add")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String bicycleAdd() {
        return "bicyclemanager/bicycleAdd";
    }


    @PostMapping("/bicycle/add")
    public String addBicycle(@RequestParam("modell") String modell,
                             @RequestParam("year") int year,
                             @RequestParam("bottomBracket") String bottomBracket,
                             @RequestParam("brand") String brand,
                             @RequestParam("chain") String chain,
                             @RequestParam("saddle") String saddle,
                             @RequestParam("pedals") String pedals,
                             @RequestParam("frontHub") String frontHub,
                             @RequestParam("type") String type,
                             @RequestParam("price") double price,
                             @RequestParam("weight") double weight,
                             @RequestParam("wheelDiameter") double wheelDiameter,
                             @RequestParam("frameMaterial") String frameMaterial,
                             @RequestParam("brakeType") String brakeType,
                             @RequestParam("numberSpeeds") int numberSpeeds,
                             @RequestParam("depreciation") String depreciation,
                             @RequestParam("quantityInStock") int quantityInStock,
                             @RequestParam("description") String description, Model model) {
        Bicycle bicycle = new Bicycle(modell, year, bottomBracket, brand, chain, saddle, pedals, frontHub,
                type, price, weight, wheelDiameter, frameMaterial, brakeType, numberSpeeds, depreciation, quantityInStock, description);
        bicycleService.addBicycle(bicycle);
        return "redirect:/bicycleManager/bicycle";
    }

    @GetMapping("/bicycle/details")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String details(@RequestParam("id") Long id, Model model) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        return "bicyclemanager/bicycleDetails";
    }

    @GetMapping("/bicycle/edit/{id}")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String update(@PathVariable("id") Long id, Model model) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        return "bicyclemanager/bicycleEdit";
    }

    @PostMapping("/bicycle/edit")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String updateBicycle(@ModelAttribute("bicycle") Bicycle bicycle) {
        bicycleService.updateBicycle(bicycle);
        return "redirect:/bicycleManager/bicycle";
    }

    @GetMapping("/cataloge")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String catalogeBicycle(Model model) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        return "bicyclemanager/cataloge";
    }

    // поиск на странице bicycle
    @PostMapping("/bicycle/search")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String searchBicyclesByModell(@RequestParam("modell") String modell, Model model) {
        List<Bicycle> bicycles = bicycleService.searchBicyclesByModell(modell);
        model.addAttribute("bicycles", bicycles);
        return "bicyclemanager/bicycle";
    }

    // поиск на странице cataloge
    @PostMapping("/cataloge/search")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String searchBicyclesCataloge(@RequestParam("modell") String modell, Model model) {
        List<Bicycle> bicycles = bicycleService.searchBicyclesByModell(modell);
        model.addAttribute("bicycles", bicycles);
        return "bicyclemanager/cataloge";
    }






}
