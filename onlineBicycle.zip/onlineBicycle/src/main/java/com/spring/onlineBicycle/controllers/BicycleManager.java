package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.models.DeliveryImage;
import com.spring.onlineBicycle.services.BicycleService;
import com.spring.onlineBicycle.services.DeliveryImageService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/bicycleManager")
@AllArgsConstructor
public class BicycleManager {

    private final BicycleService bicycleService;
    private final DeliveryImageService deliveryImageService;

    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String showHomePage() {
        return "bicyclemanager/home";
    }

    @GetMapping("/deliveryPayment")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String deliveryPaymentPage(Model model) {
        List<DeliveryImage> deliveryImages = deliveryImageService.getAllDeliveryImages();
        model.addAttribute("deliveryImages", deliveryImages); // добавить deliveryImages в модель
        return "bicyclemanager/deliveryPayment";
    }

    @GetMapping("/bicycle")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String getAllBicycles(Model model) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        return "bicyclemanager/bicycle";
    }

    @PostMapping("/bicycle/delete")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String deleteBicycle(@RequestParam("id") Long id) {
        bicycleService.deleteBicycleById(id);
        return "redirect:/bicycleManager/bicycle";
    }

    @GetMapping("/bicycle/add")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String bicycleAdd() {
        return "bicyclemanager/bicycleAdd";
    }

//    @PostMapping("/bicycle/add")
//    public String addBicycle(@RequestParam("modell") String modell,
//                             @RequestParam("year") int year,
//                             @RequestParam("bottomBracket") String bottomBracket,
//                             @RequestParam("brand") String brand,
//                             @RequestParam("chain") String chain,
//                             @RequestParam("saddle") String saddle,
//                             @RequestParam("pedals") String pedals,
//                             @RequestParam("frontHub") String frontHub,
//                             @RequestParam("type") String type,
//                             @RequestParam("price") double price,
//                             @RequestParam("weight") double weight,
//                             @RequestParam("wheelDiameter") double wheelDiameter,
//                             @RequestParam("frameMaterial") String frameMaterial,
//                             @RequestParam("brakeType") String brakeType,
//                             @RequestParam("numberSpeeds") int numberSpeeds,
//                             @RequestParam("depreciation") String depreciation,
//                             @RequestParam("quantityInStock") int quantityInStock,
//                             @RequestParam("description") String description, Model model) {
//        Bicycle bicycle = new Bicycle(modell, year, bottomBracket, brand, chain, saddle, pedals, frontHub,
//                type, price, weight, wheelDiameter, frameMaterial, brakeType, numberSpeeds, depreciation, quantityInStock, description);
//        bicycleService.addBicycle(bicycle);
//        return "redirect:/bicycleManager/bicycle";
//    }

    @GetMapping("/bicycle/details")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String details(@RequestParam("id") Long id, Model model) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        return "bicyclemanager/bicycleDetails";
    }

    @GetMapping("/bicycle/edit/{id}")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String update(@PathVariable("id") Long id, Model model) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        return "bicyclemanager/bicycleEdit";
    }

    @PostMapping("/bicycle/edit")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String updateBicycle(@ModelAttribute("bicycle") Bicycle bicycle) {
        bicycleService.updateBicycle(bicycle);
        return "redirect:/bicycleManager/bicycle";
    }

    @GetMapping("/cataloge")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String catalogeBicycle(Model model) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        return "bicyclemanager/cataloge";
    }

    @PostMapping("/bicycle/search")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String searchBicyclesByModell(@RequestParam("modell") String modell, Model model) {
        List<Bicycle> bicycles = bicycleService.searchBicyclesByModell(modell);
        model.addAttribute("bicycles", bicycles);
        return "bicyclemanager/bicycle";
    }

    @PostMapping("/cataloge/search")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String searchBicyclesCataloge(@RequestParam("modell") String modell, Model model) {
        List<Bicycle> bicycles = bicycleService.searchBicyclesByModell(modell);
        model.addAttribute("bicycles", bicycles);
        return "bicyclemanager/cataloge";
    }

    @PostMapping("/bicycle/add")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String addBicycle(@RequestParam("modell") String modell,
                             @RequestParam("year") int year,
                             @RequestParam("bottomBracket") String bottomBracket,
                             @RequestParam("brand") String brand,
                             @RequestParam("chain") String chain,
                             @RequestParam("saddle") String saddle,
                             @RequestParam("pedals") String pedals,
                             @RequestParam("frontHub") String frontHub,
                             @RequestParam("type") String type,
                             @RequestParam("price") double price,
                             @RequestParam("weight") double weight,
                             @RequestParam("wheelDiameter") double wheelDiameter,
                             @RequestParam("frameMaterial") String frameMaterial,
                             @RequestParam("brakeType") String brakeType,
                             @RequestParam("numberSpeeds") int numberSpeeds,
                             @RequestParam("depreciation") String depreciation,
                             @RequestParam("quantityInStock") int quantityInStock,
                             @RequestParam("description") String description,
                             @RequestParam("image") MultipartFile image, Model model) {
        try {
            byte[] imageData = image.getBytes(); // Получаем массив байтов изображения
            Bicycle bicycle = new Bicycle(modell, year, bottomBracket, brand, chain, saddle, pedals, frontHub,
                    type, price, weight, wheelDiameter, frameMaterial, brakeType, numberSpeeds, depreciation, quantityInStock, description);
            bicycle.setImageData(imageData); // Устанавливаем изображение в объект Bicycle
            bicycleService.addBicycle(bicycle); // Сохраняем велосипед в базе данных
        } catch (IOException e) {
            // Обработка ошибки, если что-то пошло не так при чтении изображения
            e.printStackTrace();
        }
        return "redirect:/bicycleManager/bicycle";
    }

    @GetMapping("/cataloge/{id}")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public ResponseEntity<byte[]> getImageById(@PathVariable("id") Long id) {
        Bicycle bicycle = bicycleService.getBicycleImageById(id);
        if (bicycle != null && bicycle.getImageData() != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_JPEG); // или MediaType.IMAGE_PNG, в зависимости от формата изображения
            return new ResponseEntity<>(bicycle.getImageData(), headers, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/deliveryPayment/{id}")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public ResponseEntity<byte[]> getDeliveryImage(@PathVariable String id) {
        try {
            Long deliveryId = Long.parseLong(id);
            DeliveryImage deliveryImage = deliveryImageService.getDeliveryImageById(deliveryId);
            if (deliveryImage != null && deliveryImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(deliveryImage.getImageData().length);
                return new ResponseEntity<>(deliveryImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }



}
