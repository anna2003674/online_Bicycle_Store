package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.services.BicycleService;
import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/bicycleManager")
@AllArgsConstructor
public class BicycleManager {

    private final BicycleService bicycleService;

    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String showHomePage() {
        return "bicyclemanager/home";
    }

    @GetMapping("/cataloge")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String catalogHome() {
        return "bicyclemanager/cataloge";
    }


    @GetMapping("/bicycle")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String getAllBicycles(Model model) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        return "bicyclemanager/bicycle";
    }


    @PostMapping("/bicycle/delete")
    @PreAuthorize("hasAuthority('ROLE_BICYCLEMANAGER')")
    public String deleteBicycle(@RequestParam("id") Long id) {
        bicycleService.deleteBicycleById(id);
        return "redirect:/bicycleManager/bicycle"; // Перенаправление на страницу с велосипедами после удаления
    }




//    @PostMapping("/bicycle/add")
//    public String addBicycle(@RequestParam("image") MultipartFile image,
//                             @RequestParam("modell") String modell,
//                             @RequestParam("year") int year,
//                             @RequestParam("bottomBracket") String bottomBracket,
//                             @RequestParam("brand") String brand,
//                             @RequestParam("chain") String chain,
//                             @RequestParam("saddle") String saddle,
//                             @RequestParam("pedals") String pedals,
//                             @RequestParam("frontHub") String frontHub,
//                             @RequestParam("type") String type,
//                             @RequestParam("price") double price,
//                             @RequestParam("weight") double weight,
//                             @RequestParam("wheelDiameter") double wheelDiameter,
//                             @RequestParam("frameMaterial") String frameMaterial,
//                             @RequestParam("brakeType") String brakeType,
//                             @RequestParam("numberSpeeds") int numberSpeeds,
//                             @RequestParam("depreciation") String depreciation,
//                             @RequestParam("quantityInStock") int quantityInStock,
//                             @RequestParam("description") String description) {
//        try {
//            byte[] imageData = image.getBytes(); // Получение массива байт изображения
//            Bicycle bicycle = new Bicycle(modell,year,bottomBracket,brand,chain,saddle,pedals,frontHub,
//                    type,price,weight,wheelDiameter,frameMaterial,brakeType,numberSpeeds,depreciation,quantityInStock,description);
//            bicycle.setImage(imageData); // Установка изображения в объект Bicycle
//            bicycleService.addBicycle(bicycle); // Сохранение объекта Bicycle в базу данных
//            return "redirect:/bicycleManager/cataloge"; // Перенаправление на страницу каталога после успешного добавления
//        } catch (IOException e) {
//            e.printStackTrace();
//            return "error"; // Верните страницу с ошибкой в случае неудачи
//        }
//    }

}
