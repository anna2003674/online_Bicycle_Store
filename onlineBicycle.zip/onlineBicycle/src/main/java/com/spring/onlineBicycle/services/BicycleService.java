package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.repositories.BicycleRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class BicycleService {
    private final BicycleRepository bicycleRepository;

    public BicycleService(BicycleRepository bicycleRepository) {
        this.bicycleRepository = bicycleRepository;
    }

    public List<Bicycle> getAllBicycles() {
        return bicycleRepository.findAll();
    }

    public void deleteBicycleById(Long id) {
        bicycleRepository.deleteById(id);
    }

    public void addBicycle(Bicycle bicycle) {
        bicycleRepository.save(bicycle);
    }

    public Bicycle getBicycleById(Long id) {
        Optional<Bicycle> optionalBicycle = bicycleRepository.findById(id);
        return optionalBicycle.orElse(null);
    }

    public void updateBicycle(Bicycle bicycle) {
        Optional<Bicycle> optionalBicycle = bicycleRepository.findById(bicycle.getId());
        optionalBicycle.ifPresent(existingBicycle -> {
            existingBicycle.setModell(bicycle.getModell());
            existingBicycle.setYear(bicycle.getYear());
            existingBicycle.setBottomBracket(bicycle.getBottomBracket());
            existingBicycle.setBrand(bicycle.getBrand());
            existingBicycle.setChain(bicycle.getChain());
            existingBicycle.setSaddle(bicycle.getSaddle());
            existingBicycle.setPedals(bicycle.getPedals());
            existingBicycle.setFrontHub(bicycle.getFrontHub());
            existingBicycle.setType(bicycle.getType());
            existingBicycle.setPrice(bicycle.getPrice());
            existingBicycle.setWeight(bicycle.getWeight());
            existingBicycle.setWheelDiameter(bicycle.getWheelDiameter());
            existingBicycle.setFrameMaterial(bicycle.getFrameMaterial());
            existingBicycle.setBrakeType(bicycle.getBrakeType());
            existingBicycle.setNumberSpeeds(bicycle.getNumberSpeeds());
            existingBicycle.setDepreciation(bicycle.getDepreciation());
            existingBicycle.setQuantityInStock(bicycle.getQuantityInStock());
            existingBicycle.setDescription(bicycle.getDescription());
            bicycleRepository.save(existingBicycle);
        });
    }


    public List<Bicycle> searchBicyclesByModell(String modell) {
        return bicycleRepository.findByModellContainingIgnoreCase(modell);
    }




}