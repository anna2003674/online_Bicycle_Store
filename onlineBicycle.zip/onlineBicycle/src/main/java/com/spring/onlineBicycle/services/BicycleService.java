package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.repositories.BicycleRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BicycleService {
    private final BicycleRepository bicycleRepository;

    public BicycleService(BicycleRepository bicycleRepository) {
        this.bicycleRepository = bicycleRepository;
    }


    // Метод для получения всех велосипедов из базы данных
    public List<Bicycle> getAllBicycles() {
        return bicycleRepository.findAll();
    }

    // Метод для удаления велосипеда по его идентификатору
    public void deleteBicycleById(Long id) {
        bicycleRepository.deleteById(id);
    }


}