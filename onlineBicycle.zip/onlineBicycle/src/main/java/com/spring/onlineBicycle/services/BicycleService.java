package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.models.BicycleFilter;
import com.spring.onlineBicycle.models.BrandImage;
import com.spring.onlineBicycle.models.ShoppingCartItem;
import com.spring.onlineBicycle.repositories.BicycleRepository;
import com.spring.onlineBicycle.repositories.ShoppingCartItemRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.persistence.criteria.Predicate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class BicycleService {

    private final EntityManager entityManager;

    private final BicycleRepository bicycleRepository;

    @Autowired
    public BicycleService(EntityManager entityManager, BicycleRepository bicycleRepository) {
        this.entityManager = entityManager;
        this.bicycleRepository = bicycleRepository;
    }

    public List<Bicycle> getAllBicycles() {
        return bicycleRepository.findAll();
    }

//    public List<Bicycle> getAllBicycles() {
//        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
//        CriteriaQuery<Bicycle> criteriaQuery = criteriaBuilder.createQuery(Bicycle.class);
//        Root<Bicycle> root = criteriaQuery.from(Bicycle.class);
//        criteriaQuery.select(root);
//        TypedQuery<Bicycle> typedQuery = entityManager.createQuery(criteriaQuery);
//        return typedQuery.getResultList();
//    }

    public void deleteBicycleById(Long id) {
        bicycleRepository.deleteById(id);
    }


    public void addBicycle(Bicycle bicycle) {
        bicycleRepository.save(bicycle);
    }

    public Bicycle getBicycleById(Long id) {
        Optional<Bicycle> optionalBicycle = bicycleRepository.findById(id);
        return optionalBicycle.orElse(null);
    }

    public void updateBicycle(Bicycle bicycle) {
        Optional<Bicycle> optionalBicycle = bicycleRepository.findById(bicycle.getId());
        optionalBicycle.ifPresent(existingBicycle -> {
            existingBicycle.setModell(bicycle.getModell());
            existingBicycle.setYear(bicycle.getYear());
            existingBicycle.setBottomBracket(bicycle.getBottomBracket());
            existingBicycle.setBrand(bicycle.getBrand());
            existingBicycle.setChain(bicycle.getChain());
            existingBicycle.setSaddle(bicycle.getSaddle());
            existingBicycle.setPedals(bicycle.getPedals());
            existingBicycle.setFrontHub(bicycle.getFrontHub());
            existingBicycle.setType(bicycle.getType());
            existingBicycle.setPrice(bicycle.getPrice());
            existingBicycle.setWeight(bicycle.getWeight());
            existingBicycle.setWheelDiameter(bicycle.getWheelDiameter());
            existingBicycle.setFrameMaterial(bicycle.getFrameMaterial());
            existingBicycle.setBrakeType(bicycle.getBrakeType());
            existingBicycle.setNumberSpeeds(bicycle.getNumberSpeeds());
            existingBicycle.setDepreciation(bicycle.getDepreciation());
            existingBicycle.setQuantityInStock(bicycle.getQuantityInStock());
            existingBicycle.setDescription(bicycle.getDescription());
            existingBicycle.setImageData(bicycle.getImageData());
            bicycleRepository.save(existingBicycle);
        });
    }

    public List<Bicycle> searchBicyclesByModell(String modell) {
        return bicycleRepository.findByModellContainingIgnoreCase(modell);
    }

    // для добавления в бд изображений велосипедов
    public void saveBicycleImage(byte[] imageData) {
        Bicycle bicycleImage = new Bicycle();
        bicycleImage.setImageData(imageData);
        bicycleRepository.save(bicycleImage);
    }

    public List<Bicycle> getAllBicycleImages() {
        return bicycleRepository.findAll();
    }

    public Bicycle getBicycleImageById(Long id) {
        return bicycleRepository.findById(id).orElse(null);
    }

//    public List<Bicycle> filterBicycles(BicycleFilter filter) {
//        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
//        CriteriaQuery<Bicycle> criteriaQuery = criteriaBuilder.createQuery(Bicycle.class);
//        Root<Bicycle> root = criteriaQuery.from(Bicycle.class);
//
//        List<Predicate> predicates = new ArrayList<>();
//
//        // Добавление условий фильтрации в зависимости от наличия значений в объекте filter
//
//        if (filter.getBrand() != null) {
//            predicates.add(criteriaBuilder.equal(root.get("brand"), filter.getBrand()));
//        }
//
//        if (filter.getWheelDiameter() != null) {
//            predicates.add(criteriaBuilder.equal(root.get("wheelDiameter"), filter.getWheelDiameter()));
//        }
//
//        if (filter.getYear() != 0) {
//            predicates.add(criteriaBuilder.equal(root.get("year"), filter.getYear()));
//        }
//        if (filter.getNumberSpeeds() != 0) {
//            predicates.add(criteriaBuilder.equal(root.get("numberSpeeds"), filter.getNumberSpeeds()));
//        }
//
//        if (filter.getType() != null) {
//            predicates.add(criteriaBuilder.equal(root.get("type"), filter.getType()));
//        }
//
//        if (filter.getWeight() != null) {
//            predicates.add(criteriaBuilder.equal(root.get("weight"), filter.getWeight()));
//        }
//
//        // Собираем все предикаты в один предикат для использования в запросе
//        Predicate finalPredicate = criteriaBuilder.and(predicates.toArray(new Predicate[0]));
//
//        // Добавляем предикаты в запрос
//        criteriaQuery.where(finalPredicate);
//
//        // Выполняем запрос и возвращаем результат
//        TypedQuery<Bicycle> typedQuery = entityManager.createQuery(criteriaQuery);
//        return typedQuery.getResultList();
//    }



    public List<Bicycle> filterBicycles(BicycleFilter filter) {
        try {
            CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
            CriteriaQuery<Bicycle> criteriaQuery = criteriaBuilder.createQuery(Bicycle.class);
            Root<Bicycle> root = criteriaQuery.from(Bicycle.class);

            List<Predicate> predicates = new ArrayList<>();

            if (filter.getBrand() != null && !filter.getBrand().isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("brand"), filter.getBrand()));
            }

            if (filter.getWheelDiameter() != null && !filter.getWheelDiameter().isEmpty()) {
                try {
                    double wheelDiameter = Double.parseDouble(filter.getWheelDiameter());
                    predicates.add(criteriaBuilder.equal(root.get("wheelDiameter"), wheelDiameter));
                } catch (NumberFormatException e) {
                    return Collections.emptyList();
                }
            }

            if (filter.getYear() != 0) {
                predicates.add(criteriaBuilder.equal(root.get("year"), filter.getYear()));
            }

            if (filter.getNumberSpeeds() != 0) {
                predicates.add(criteriaBuilder.equal(root.get("numberSpeeds"), filter.getNumberSpeeds()));
            }

            if (filter.getType() != null && !filter.getType().isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("type"), filter.getType()));
            }

            if (filter.getWeight() != null && !filter.getWeight().isEmpty()) {
                try {
                    double weight = Double.parseDouble(filter.getWeight());
                    predicates.add(criteriaBuilder.equal(root.get("weight"), weight));
                } catch (NumberFormatException e) {
                    return Collections.emptyList();
                }
            }

            Predicate finalPredicate = criteriaBuilder.and(predicates.toArray(new Predicate[0]));
            criteriaQuery.where(finalPredicate);

            TypedQuery<Bicycle> typedQuery = entityManager.createQuery(criteriaQuery);
            return typedQuery.getResultList();
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }


    // по весу
//    public List<Bicycle> filterBicyclesWeigh(BicycleFilter filter) {
//        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
//        CriteriaQuery<Bicycle> criteriaQuery = criteriaBuilder.createQuery(Bicycle.class);
//        Root<Bicycle> root = criteriaQuery.from(Bicycle.class);
//
//        List<Predicate> predicates = new ArrayList<>();
//
//        // Добавление условий фильтрации в зависимости от наличия значений в объекте filter
//
//        if (filter.getWeight() != null) {
//            predicates.add(criteriaBuilder.equal(root.get("weight"), filter.getWeight()));
//        }
//
//        // Собираем все предикаты в один предикат для использования в запросе
//        Predicate finalPredicate = criteriaBuilder.and(predicates.toArray(new Predicate[0]));
//
//        // Добавляем предикаты в запрос
//        criteriaQuery.where(finalPredicate);
//
//        // Выполняем запрос и возвращаем результат
//        TypedQuery<Bicycle> typedQuery = entityManager.createQuery(criteriaQuery);
//        return typedQuery.getResultList();
//    }


    // по бренду и количеству скоростей
//    public List<Bicycle> filterBicyclesBrands(BicycleFilter filter) {
//        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
//        CriteriaQuery<Bicycle> criteriaQuery = criteriaBuilder.createQuery(Bicycle.class);
//        Root<Bicycle> root = criteriaQuery.from(Bicycle.class);
//
//        List<Predicate> predicates = new ArrayList<>();
//
//        // Добавление условий фильтрации в зависимости от наличия значений в объекте filter
//
//        if (filter.getBrand() != null) {
//            predicates.add(criteriaBuilder.equal(root.get("brand"), filter.getBrand()));
//        }
//
//        if (filter.getNumberSpeeds() != 0) {
//            predicates.add(criteriaBuilder.equal(root.get("numberSpeeds"), filter.getNumberSpeeds()));
//        }
//
//        // Собираем все предикаты в один предикат для использования в запросе
//        Predicate finalPredicate = criteriaBuilder.and(predicates.toArray(new Predicate[0]));
//
//        // Добавляем предикаты в запрос
//        criteriaQuery.where(finalPredicate);
//
//        // Выполняем запрос и возвращаем результат
//        TypedQuery<Bicycle> typedQuery = entityManager.createQuery(criteriaQuery);
//        return typedQuery.getResultList();
//    }




    public List<Bicycle> filterBicyclesBrands(BicycleFilter filter) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Bicycle> criteriaQuery = criteriaBuilder.createQuery(Bicycle.class);
        Root<Bicycle> root = criteriaQuery.from(Bicycle.class);

        List<Predicate> predicates = new ArrayList<>();

        // Добавление условий фильтрации в зависимости от наличия значений в объекте filter
        if (filter.getBrand() != null && !filter.getBrand().isEmpty()) {
            predicates.add(criteriaBuilder.equal(root.get("brand"), filter.getBrand()));
        }

        if (filter.getNumberSpeeds() != 0) {
            predicates.add(criteriaBuilder.equal(root.get("numberSpeeds"), filter.getNumberSpeeds()));
        }

        // Собираем все предикаты в один предикат для использования в запросе
        Predicate finalPredicate = criteriaBuilder.and(predicates.toArray(new Predicate[0]));

        // Добавляем предикаты в запрос
        criteriaQuery.where(finalPredicate);

        // Выполняем запрос и возвращаем результат
        TypedQuery<Bicycle> typedQuery = entityManager.createQuery(criteriaQuery);
        return typedQuery.getResultList();
    }




//     по диаметру колес
//    public List<Bicycle> filterBicyclesWheelDiameter(BicycleFilter filter) {
//        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
//        CriteriaQuery<Bicycle> criteriaQuery = criteriaBuilder.createQuery(Bicycle.class);
//        Root<Bicycle> root = criteriaQuery.from(Bicycle.class);
//
//        List<Predicate> predicates = new ArrayList<>();
//
//        // Добавление условий фильтрации в зависимости от наличия значений в объекте filter
//        if (filter.getWheelDiameter() != null) {
//            predicates.add(criteriaBuilder.equal(root.get("wheelDiameter"), filter.getWheelDiameter()));
//        }
//
//        // Собираем все предикаты в один предикат для использования в запросе
//        Predicate finalPredicate = criteriaBuilder.and(predicates.toArray(new Predicate[0]));
//
//        // Добавляем предикаты в запрос
//        criteriaQuery.where(finalPredicate);
//
//        // Выполняем запрос и возвращаем результат
//        TypedQuery<Bicycle> typedQuery = entityManager.createQuery(criteriaQuery);
//        return typedQuery.getResultList();
//    }



    // фильтр по диаметру колес
    public List<Bicycle> filterBicyclesWheelDiameter(BicycleFilter filter) {
        String wheelDiameterStr = filter.getWheelDiameter();
        if (wheelDiameterStr == null || !isNumeric(wheelDiameterStr)) {
            return Collections.emptyList();
        }
        double diameter = Double.parseDouble(wheelDiameterStr);
        return bicycleRepository.findByWheelDiameter(diameter);
    }

    private boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }


    // фильтр по весу
    public List<Bicycle> filterBicyclesWeigh(BicycleFilter filter) {
        if (filter.getWeight() == null) {
            return Collections.emptyList();
        }

        try {
            double weight = Double.parseDouble(filter.getWeight());
            return bicycleRepository.findByWeight(weight);
        } catch (NumberFormatException e) {
            return Collections.emptyList();
        }
    }







}