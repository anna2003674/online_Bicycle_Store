package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.repositories.BicycleRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BicycleService {
    private final BicycleRepository bicycleRepository;

    public BicycleService(BicycleRepository bicycleRepository) {
        this.bicycleRepository = bicycleRepository;
    }

    public List<Bicycle> getAllBicycles() {
        return bicycleRepository.findAll();
    }

    public void deleteBicycleById(Long id) {
        bicycleRepository.deleteById(id);
    }

    public void addBicycle(Bicycle bicycle) {
        bicycleRepository.save(bicycle);
    }

    public Bicycle getBicycleById(Long id) {
        Optional<Bicycle> optionalBicycle = bicycleRepository.findById(id);
        return optionalBicycle.orElse(null);
    }


}