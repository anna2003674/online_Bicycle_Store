package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.*;
import com.spring.onlineBicycle.services.*;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@AllArgsConstructor
public class MainController {

    private final BrandImageService brandImageService;

    private final BicycleService bicycleService;
    private final DeliveryImageService deliveryImageService;
    private final CompanyImageService companyImageService;
    private final SliderImageService sliderImageService;

    @GetMapping("/home")
    public String home(Model model) {
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("sliderImages", sliderImages);
        model.addAttribute("title", "Главная страница сайта");
        return "home";
    }

    @GetMapping("/about")
    public String about(Model model) {
        List<CompanyImage> companyImages = companyImageService.getAllCompanyImages();
        model.addAttribute("companyImages", companyImages);
        model.addAttribute("title", "О нас");
        return "about";
    }

    @GetMapping("/catalog")
    public String catalogGet(Model model) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        return "user/cataloge";
    }

    @GetMapping("/contact")
    public String contact(Model model) {
        model.addAttribute("title", "Контакты");
        return "contact";
    }

    @GetMapping("/brands")
    public String brands(Model model) {
        List<BrandImage> brandImages = brandImageService.getAllBrandImages();
        model.addAttribute("brandImages", brandImages);
        return "brands";
    }

    @GetMapping("/brands/{id}")
    public ResponseEntity<byte[]> getBrandImage(@PathVariable String id) {
        try {
            Long brandId = Long.parseLong(id);
            BrandImage brandImage = brandImageService.getBrandImageById(brandId);
            if (brandImage != null && brandImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(brandImage.getImageData().length);
                return new ResponseEntity<>(brandImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }

    @GetMapping("/deliveryPayment")
    public String deliveryPayment(Model model) {
        List<DeliveryImage> deliveryImages = deliveryImageService.getAllDeliveryImages();
        model.addAttribute("title", "Доставка и оплата");
        model.addAttribute("deliveryImages", deliveryImages); // добавить deliveryImages в модель
        return "deliveryPayment";
    }

    @GetMapping("/cataloge")
    public String catalog(Model model) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        return "cataloge";
    }

    @GetMapping("/cataloge/details")
    public String details(@RequestParam("id") Long id, Model model) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        return "bicycle-details";
    }

    @PostMapping("/cataloge/search")
    public String searchBicycle(@RequestParam("modell") String modell, Model model) {
        List<Bicycle> bicycles = bicycleService.searchBicyclesByModell(modell);
        model.addAttribute("bicycles", bicycles);
        return "cataloge";
    }

    @GetMapping("/shoppingCart")
    public String shoppingCart(Model model) {
        model.addAttribute("shoppingCart", "Корзина");
        return "shoppingCart";
    }

    // для загрузки изображений (брендов) велосипедов
    @GetMapping("/upload")
    public String uploadImage(Model model) {
        model.addAttribute("imageForm", "imageForms");
        return "imagefile";
    }

    @GetMapping("/cataloge/{id}")
    public ResponseEntity<byte[]> getBicycleImageById(@PathVariable("id") Long id) {
        Bicycle bicycle = bicycleService.getBicycleImageById(id);
        if (bicycle != null && bicycle.getImageData() != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_JPEG); // или MediaType.IMAGE_PNG, в зависимости от формата изображения
            return new ResponseEntity<>(bicycle.getImageData(), headers, HttpStatus.OK);
        } else {
            // Здесь вы можете вернуть пустое изображение или сообщение об ошибке, в зависимости от вашего случая
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/upload3")
    public String uploadDeliveryImage(Model model) {
        model.addAttribute("imageForm", "imageForms");
        return "imagefile2";
    }

    @GetMapping("/deliveryPayment/{id}")
    public ResponseEntity<byte[]> getDeliveryImage(@PathVariable String id) {
        try {
            Long deliveryId = Long.parseLong(id);
            DeliveryImage deliveryImage = deliveryImageService.getDeliveryImageById(deliveryId);
            if (deliveryImage != null && deliveryImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(deliveryImage.getImageData().length);
                return new ResponseEntity<>(deliveryImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }

    @GetMapping("/upload4")
    public String uploadCompanyImage(Model model) {
        model.addAttribute("imageForm", "imageForms");
        return "imagefile3";
    }


    @GetMapping("/about/{id}")
    public ResponseEntity<byte[]> getCompanyImage(@PathVariable String id) {
        try {
            Long companyId = Long.parseLong(id);
            CompanyImage companyImage = companyImageService.getCompanyImageById(companyId);
            if (companyImage != null && companyImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(companyImage.getImageData().length);
                return new ResponseEntity<>(companyImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }

    @GetMapping("/upload5")
    public String uploadSliderImage(Model model) {
        model.addAttribute("imageForm", "imageForms");
        return "imagefile4";
    }

    @GetMapping("/home/{id}")
    public ResponseEntity<byte[]> getSliderImage(@PathVariable String id) {
        try {
            Long sliderId = Long.parseLong(id);
            SliderImage sliderImage = sliderImageService.getSliderImageById(sliderId);
            if (sliderImage != null && sliderImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(sliderImage.getImageData().length);
                return new ResponseEntity<>(sliderImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }


    // фильтр по всем полям
    @PostMapping("/cataloge/filter")
    public String filterBicyclesCatalog(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicycles(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "cataloge";
    }

    // фильтр по всем полям
    @GetMapping("/cataloge/filter")
    public String filterBicyclesCatalogGet(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicycles(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "cataloge";
    }

    // фильтр по весу
    @PostMapping("/cataloge/filterWeigh")
    public String filterBicyclesCatalogWeigh(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWeigh(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "cataloge";
    }

    // фильтр по весу
    @GetMapping("/cataloge/filterWeigh")
    public String filterBicyclesCatalogGetWeigh(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWeigh(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "cataloge";
    }


    // фильтр по бренду и количеству скоростей
    @PostMapping("/cataloge/filterBrand")
    public String filterBicyclesCatalogBrand(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesBrands(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "cataloge";
    }

    // фильтр по бренду и количеству скоростей
    @GetMapping("/cataloge/filterBrand")
    public String filterBicyclesCatalogGetBrand(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesBrands(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "cataloge";
    }


    // фильтр по диаметру колес
    @PostMapping("/cataloge/filterWheelDiameter")
    public String filterBicyclesCatalogWheelDiameter(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWheelDiameter(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "cataloge";
    }

    // фильтр по диаметру колес
    @GetMapping("/cataloge/filterWheelDiameter")
    public String filterBicyclesCatalogGetWheelDiameter(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWheelDiameter(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "cataloge";
    }




}
