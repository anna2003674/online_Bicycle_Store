package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.services.BicycleService;
import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@AllArgsConstructor
public class MainController {

    private final BicycleService bicycleService;

    @GetMapping("/home")
    public String home(Model model) {
        model.addAttribute("title", "Главная страница сайта");
        return "home";
    }

    @GetMapping("/about")
    public String about(Model model) {
        model.addAttribute("title", "О нас");
        return "about";
    }

    @GetMapping("/contact")
    public String contact(Model model) {
        model.addAttribute("title", "Контакты");
        return "contact";
    }


    @GetMapping("/brands")
    public String brands(Model model) {
        model.addAttribute("title", "Бренды");
        return "brands";

    }

    @GetMapping("/deliveryPayment")
    public String deliveryPayment(Model model) {
        model.addAttribute("title", "Доставка и оплата");
        return "deliveryPayment";
    }

    // виден каталог велосипедов
    @GetMapping("/cataloge")
    public String catalog(Model model) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        return "cataloge";
    }


    // кнопка детальнее
    @GetMapping("/cataloge/details")
    public String details(@RequestParam("id") Long id, Model model) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        return "bicycle-details";
    }

    // поиск велосипеда по модели
    @PostMapping("/cataloge/search")
    public String searchBicycle(@RequestParam("modell") String modell, Model model) {
        List<Bicycle> bicycles = bicycleService.searchBicyclesByModell(modell);
        model.addAttribute("bicycles", bicycles);
        return "cataloge";
    }

    @GetMapping("/shoppingCart")
    public String shoppingCart(Model model) {
        model.addAttribute("shoppingCart", "Корзина");
        return "shoppingCart";
    }








}
