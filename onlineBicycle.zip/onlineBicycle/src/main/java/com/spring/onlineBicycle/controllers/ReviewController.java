package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.Review;
import com.spring.onlineBicycle.services.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ReviewController {

    private final ReviewService reviewService;

    @Autowired
    public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @GetMapping("/reviews")
    public String showReviews(Model model) {
        model.addAttribute("reviews", reviewService.getAllReviews());
        return "reviews";
    }

    @GetMapping("/administrator/reviews")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String showReviewsAdmin(Model model) {
        model.addAttribute("reviews", reviewService.getAllReviews());
        return "administrator/reviews";
    }

    @PostMapping("/administrator/reviews")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String addReviewAdmin(Review review) {
        reviewService.addReview(review);
        return "redirect:/administrator/reviews";
    }

    @PostMapping("/administrator/reviews/delete")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String deleteReviewAdmin(Long id) {
        reviewService.deleteReview(id);
        return "redirect:/administrator/reviews";
    }

    @GetMapping("/users/reviews")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String showReviewsUser(Model model) {
        model.addAttribute("reviews", reviewService.getAllReviews());
        return "user/reviews";
    }

    @PostMapping("/users/reviews")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String addReviewUser(Review review) {
        reviewService.addReview(review);
        return "redirect:/users/reviews";
    }


}
