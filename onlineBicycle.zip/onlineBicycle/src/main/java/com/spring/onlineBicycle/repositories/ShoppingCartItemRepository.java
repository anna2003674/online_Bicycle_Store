package com.spring.onlineBicycle.repositories;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.models.MyUser;
import com.spring.onlineBicycle.models.ShoppingCartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ShoppingCartItemRepository extends JpaRepository<ShoppingCartItem, Long> {
//    ShoppingCartItem findByBicycle(Bicycle bicycle);
    ShoppingCartItem findByBicycleAndUsername(Bicycle bicycle, String username);
    List<ShoppingCartItem> findByUsername(String username);
    ShoppingCartItem findByBicycleIdAndUsername(Long bicycleId, String username);
}
