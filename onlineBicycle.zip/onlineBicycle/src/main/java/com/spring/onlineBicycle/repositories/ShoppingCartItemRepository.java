package com.spring.onlineBicycle.repositories;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.models.ShoppingCartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ShoppingCartItemRepository extends JpaRepository<ShoppingCartItem, Long> {
    ShoppingCartItem findByBicycle(Bicycle bicycle);
}
