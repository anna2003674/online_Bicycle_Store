package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.models.ShoppingCartItem;
import com.spring.onlineBicycle.repositories.ShoppingCartItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShoppingCartService {
    private final ShoppingCartItemRepository cartItemRepository;

    @Autowired
    public ShoppingCartService(ShoppingCartItemRepository cartItemRepository) {
        this.cartItemRepository = cartItemRepository;
    }




    public List<ShoppingCartItem> getCartItems() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        return cartItemRepository.findByUsername(username);
    }

    public void addToCart(Bicycle bicycle) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        ShoppingCartItem item = cartItemRepository.findByBicycleAndUsername(bicycle, username);
        if (item != null) {
            item.setQuantity(item.getQuantity() + 1);
        } else {
            item = new ShoppingCartItem(bicycle, 1, username);
        }
        cartItemRepository.save(item);
    }


//    public List<ShoppingCartItem> getCartItems() {
//        return cartItemRepository.findAll();
//    }

//    public void addToCart(Bicycle bicycle) {
//        ShoppingCartItem item = cartItemRepository.findByBicycle(bicycle);
//        if (item != null) {
//            item.setQuantity(item.getQuantity() + 1);
//        } else {
//            item = new ShoppingCartItem(bicycle, 1);
//        }
//        cartItemRepository.save(item);
//    }


    public void removeFromCart(Long itemId) {
        cartItemRepository.deleteById(itemId);
    }

    public void clearCart() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        List<ShoppingCartItem> cartItems = cartItemRepository.findByUsername(username);
        cartItemRepository.deleteAll(cartItems);
    }

}