package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.models.MyUser;
import com.spring.onlineBicycle.models.ShoppingCartItem;
import com.spring.onlineBicycle.repositories.ShoppingCartItemRepository;
import com.spring.onlineBicycle.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShoppingCartService {
    private final ShoppingCartItemRepository cartItemRepository;
    private final UserRepository userRepository;

    @Autowired
    public ShoppingCartService(ShoppingCartItemRepository cartItemRepository, UserRepository userRepository) {
        this.cartItemRepository = cartItemRepository;
        this.userRepository = userRepository;
    }

    public List<ShoppingCartItem> getCartItems() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        return cartItemRepository.findByUsername(username);
    }

//    public void addToCart(Bicycle bicycle) {
//        String username = SecurityContextHolder.getContext().getAuthentication().getName();
//        ShoppingCartItem item = cartItemRepository.findByBicycleAndUsername(bicycle, username);
//        if (item != null) {
//            item.setQuantity(item.getQuantity() + 1);
//        } else {
//            item = new ShoppingCartItem(bicycle, 1, username);
//        }
//        cartItemRepository.save(item);
//    }


    public void addToCart(Bicycle bicycle) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        MyUser user = userRepository.findByName(username).orElse(null);
        if (user != null) {
            ShoppingCartItem item = cartItemRepository.findByBicycleAndUsername(bicycle, username);
            if (item != null) {
                item.setQuantity(item.getQuantity() + 1);
            } else {
                item = new ShoppingCartItem(bicycle, 1, username);
                item.setUser(user);
            }
            cartItemRepository.save(item);
        } else {
            // Обработка случая, когда пользователь не найден
        }
    }

    public void removeItemByBicycleIdAndItemIdAndUsername(Long bicycleId, Long itemId, String username) {
        ShoppingCartItem item = cartItemRepository.findByBicycleIdAndIdAndUsername(bicycleId, itemId, username);
        if (item != null) {
            if (item.getQuantity() > 1) {
                item.setQuantity(item.getQuantity() - 1);
                cartItemRepository.save(item);
            } else {
                cartItemRepository.delete(item);
            }
        }
    }

    public void clearCart() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        List<ShoppingCartItem> cartItems = cartItemRepository.findByUsername(username);
        cartItemRepository.deleteAll(cartItems);
    }

    public void clearCar2(String username) {
        List<ShoppingCartItem> cartItems = cartItemRepository.findByUsername(username);
        cartItemRepository.deleteAll(cartItems);
    }



}