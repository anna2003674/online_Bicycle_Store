package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.models.ShoppingCartItem;
import com.spring.onlineBicycle.repositories.ShoppingCartItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShoppingCartService {
    private final ShoppingCartItemRepository cartItemRepository;

    @Autowired
    public ShoppingCartService(ShoppingCartItemRepository cartItemRepository) {
        this.cartItemRepository = cartItemRepository;
    }

    public List<ShoppingCartItem> getCartItems() {
        return cartItemRepository.findAll();
    }

    public void addToCart(Bicycle bicycle) {
        ShoppingCartItem item = cartItemRepository.findByBicycle(bicycle);
        if (item != null) {
            item.setQuantity(item.getQuantity() + 1);
        } else {
            item = new ShoppingCartItem(bicycle, 1);
        }
        cartItemRepository.save(item);
    }

    public void removeFromCart(ShoppingCartItem item) {
        cartItemRepository.delete(item);
    }

    public void clearCart() {
        cartItemRepository.deleteAll();
    }

}