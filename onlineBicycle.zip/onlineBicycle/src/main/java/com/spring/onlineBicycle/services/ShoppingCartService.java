package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.models.ShoppingCartItem;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ShoppingCartService {

    private List<ShoppingCartItem> cartItems;

    public ShoppingCartService() {
        this.cartItems = new ArrayList<>();
    }

    public List<ShoppingCartItem> getCartItems() {
        return this.cartItems;
    }

    public void addToCart(Bicycle bicycle) {
        // Проверяем, есть ли уже такой товар в корзине
        boolean found = false;
        for (ShoppingCartItem item : cartItems) {
            if (item.getBicycle().getId().equals(bicycle.getId())) {
                // Увеличиваем количество товара в корзине
                item.setQuantity(item.getQuantity() + 1);
                found = true;
                break;
            }
        }
        if (!found) {
            // Добавляем новый товар в корзину
            ShoppingCartItem newItem = new ShoppingCartItem(bicycle, 1);
            cartItems.add(newItem);
        }
    }

//    public void removeFromCart(Bicycle bicycle) {
//        // Удаляем товар из корзины
//        cartItems.removeIf(item -> item.getBicycle().getId().equals(bicycle.getId()));
//    }
//
//    public void clearCart() {
//        // Очищаем корзину
//        cartItems.clear();
//    }

}