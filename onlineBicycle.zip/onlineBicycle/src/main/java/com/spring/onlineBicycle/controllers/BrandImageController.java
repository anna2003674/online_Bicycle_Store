package com.spring.onlineBicycle.controllers;
import com.spring.onlineBicycle.services.BrandImageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


@Controller
public class BrandImageController {

    private final BrandImageService brandImageService;

    @Autowired
    public BrandImageController(BrandImageService brandImageService) {
        this.brandImageService = brandImageService;
    }

    @PostMapping("/upload")
    @ResponseBody
    public HttpStatus uploadImage(@RequestParam("image") MultipartFile image) {
        try {
            byte[] imageData = image.getBytes();
            brandImageService.saveBrandImage(imageData);
            return HttpStatus.CREATED;
        } catch (Exception e) {
            e.printStackTrace();
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }
    }


}