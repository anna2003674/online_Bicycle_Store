package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.services.DeliveryImageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class DeliveryImageController {

    private final DeliveryImageService deliveryImageService;

    @Autowired
    public DeliveryImageController(DeliveryImageService deliveryImageService) {
        this.deliveryImageService = deliveryImageService;
    }

    @PostMapping("/upload3")
    @ResponseBody
    public HttpStatus uploadImage(@RequestParam("image") MultipartFile image) {
        try {
            byte[] imageData = image.getBytes();
            deliveryImageService.saveDeliveryImage(imageData);
            return HttpStatus.CREATED;
        } catch (Exception e) {
            e.printStackTrace();
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }
    }

}
