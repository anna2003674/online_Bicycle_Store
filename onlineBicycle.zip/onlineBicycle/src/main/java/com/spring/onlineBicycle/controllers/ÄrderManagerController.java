package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.models.Purchase;
import com.spring.onlineBicycle.services.BicycleService;
import com.spring.onlineBicycle.services.PurchaseService;
import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/orderManager")
@AllArgsConstructor
public class ОrderManagerController {

    private final PurchaseService purchaseService;
    private final BicycleService bicycleService;

    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String showHomePageAdm() {
        return "orderManager/home";
    }

    @GetMapping("/catalog")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String orderManagerCatalog(Model model) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        return "orderManager/cataloge";
    }

    @GetMapping("/orderList")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String orderList(Model model) {
        List<Purchase> orders = purchaseService.getAllOrders();
        model.addAttribute("orders", orders);
        return "orderManager/orderList";
    }

    @GetMapping("/catalog/details")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String details(@RequestParam("id") Long id, Model model) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        return "orderManager/bicycle-details";
    }
}
