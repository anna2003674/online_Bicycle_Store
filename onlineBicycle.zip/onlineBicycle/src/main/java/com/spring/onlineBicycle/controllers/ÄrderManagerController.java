package com.spring.onlineBicycle.controllers;

import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/orderManager")
@AllArgsConstructor
public class ОrderManagerController {

    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String showHomePageAdm() {
        return "orderManager/home";
    }

    @GetMapping("/oderList")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String orderList() {
        return "orderManager/orderList";
    }

    @GetMapping("/oder")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String order() {
        return "orderManager/order";
    }

    @GetMapping("/catalog")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String cataloge() {
        return "orderManager/cataloge";
    }
}
