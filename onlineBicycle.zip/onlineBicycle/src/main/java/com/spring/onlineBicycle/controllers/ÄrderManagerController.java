package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.*;
import com.spring.onlineBicycle.services.*;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.security.Principal;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/orderManager")
@AllArgsConstructor
public class ОrderManagerController {

    private final PurchaseService purchaseService;
    private final BicycleService bicycleService;
    private final SliderImageService sliderImageService;
    private final UserService userService;
    private final PasswordEncoder passwordEncoder;
    private final FavoriteService favoriteService;

    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String showHomePageAdm(Model model, Principal principal) {
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("sliderImages", sliderImages);
        model.addAttribute("title", "Главная страница сайта");
        model.addAttribute("username", principal.getName());
        return "orderManager/home";
    }

    @GetMapping("/catalog")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String orderManagerCatalog(Model model, Principal principal) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/cataloge";
    }

    @GetMapping("/orderList")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String orderList(Model model, Principal principal) {
        List<Purchase> orders = purchaseService.getAllOrders();
        model.addAttribute("orders", orders);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/orderList";
    }

    @GetMapping("/catalog/details")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String details(@RequestParam("id") Long id, Model model, Principal principal) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/bicycle-details";
    }

    // Отмена заказа
    @PostMapping("/orderList/cancel")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String cancelOrder(@RequestParam("orderId") Long orderId) {
        Purchase order = purchaseService.getOrderById(orderId);
        if (order != null) {
            order.setStatus("cancelled"); // установите статус заказа на "cancelled"
            purchaseService.updateOrder(order); // обновите заказ в базе данных
        }
        return "redirect:/orderManager/orderList"; // перенаправьте обратно к списку заказов
    }
    
    // подтверждение заказа
    @PostMapping("/orderList/confirm")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String confirmOrder(@RequestParam("orderId") Long orderId) {
        Purchase order = purchaseService.getOrderById(orderId);
        if (order != null) {
            order.setStatus("confirmed"); // установите статус заказа на "confirmed"
            purchaseService.updateOrder(order); // обновите заказ в базе данных
        }
        return "redirect:/orderManager/orderList"; // перенаправьте обратно к списку заказов
    }

    @GetMapping("/cataloge/{id}")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public ResponseEntity<byte[]> getBicycleImageById(@PathVariable("id") Long id) {
        Bicycle bicycle = bicycleService.getBicycleImageById(id);
        if (bicycle != null && bicycle.getImageData() != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_JPEG); // или MediaType.IMAGE_PNG, в зависимости от формата изображения
            return new ResponseEntity<>(bicycle.getImageData(), headers, HttpStatus.OK);
        } else {
            // Здесь вы можете вернуть пустое изображение или сообщение об ошибке, в зависимости от вашего случая
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/catalog/{id}")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public ResponseEntity<byte[]> getBicycleImage2ById(@PathVariable("id") Long id) {
        Bicycle bicycle = bicycleService.getBicycleImageById(id);
        if (bicycle != null && bicycle.getImageData() != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_JPEG); // или MediaType.IMAGE_PNG, в зависимости от формата изображения
            return new ResponseEntity<>(bicycle.getImageData(), headers, HttpStatus.OK);
        } else {
            // Здесь вы можете вернуть пустое изображение или сообщение об ошибке, в зависимости от вашего случая
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/home/{id}")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public ResponseEntity<byte[]> getSliderImage(@PathVariable String id) {
        try {
            Long sliderId = Long.parseLong(id);
            SliderImage sliderImage = sliderImageService.getSliderImageById(sliderId);
            if (sliderImage != null && sliderImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(sliderImage.getImageData().length);
                return new ResponseEntity<>(sliderImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }


    // фильтр по всем полям
    @PostMapping("/catalog/filter")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalog(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicycles(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "orderManager/cataloge";
    }

    // фильтр по всем полям
    @GetMapping("/catalog/filter")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalogGet(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicycles(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/cataloge";
    }


    // фильтр по весу
    @PostMapping("/catalog/filterWeigh")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalogWeigh(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWeigh(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "orderManager/cataloge";
    }

    // фильтр по весу
    @GetMapping("/catalog/filterWeigh")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalogGetWeigh(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWeigh(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/cataloge";
    }


    // фильтр по бренду и количеству скоростей
    @PostMapping("/catalog/filterBrand")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalogBrand(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesBrands(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "orderManager/cataloge";
    }

    // фильтр по бренду и количеству скоростей
    @GetMapping("/catalog/filterBrand")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalogGetBrand(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesBrands(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/cataloge";
    }


    // фильтр по диаметру колес
    @PostMapping("/catalog/filterWheelDiameter")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalogWheelDiameter(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWheelDiameter(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "orderManager/cataloge";
    }

    // фильтр по диаметру колес
    @GetMapping("/catalog/filterWheelDiameter")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalogGetWheelDiameter(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWheelDiameter(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/cataloge";
    }

    @PostMapping("/change-password")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String changePassword(@RequestParam("currentPassword") String currentPassword,
                                 @RequestParam("newPassword") String newPassword,
                                 @RequestParam("confirmPassword") String confirmPassword,
                                 Principal principal,
                                 Model model) {
        // Получить имя текущего пользователя
        String username = principal.getName();

        // Получить информацию о текущем пользователе
        Optional<MyUser> userOptional = userService.findByUsername(username);
        if (userOptional.isPresent()) {
            MyUser user = userOptional.get();
            // Проверить, соответствует ли текущий пароль введенному пользователем
            if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
                // Если текущий пароль не совпадает, вернуть сообщение об ошибке
                model.addAttribute("errorMessage", "Текущий пароль введен неверно");
                return "orderManager/personal-area";
            }

            // Проверить, совпадают ли новый пароль и его подтверждение
            if (!newPassword.equals(confirmPassword)) {
                // Если новый пароль и его подтверждение не совпадают, вернуть сообщение об ошибке
                model.addAttribute("errorMessage", "Новый пароль и его подтверждение не совпадают");
                return "orderManager/personal-area";
            }

            // Обновить пароль пользователя
            user.setPassword(passwordEncoder.encode(newPassword));
            userService.saveUser2(user);

            // Вернуть пользователя на страницу личного кабинета с сообщением об успешном изменении пароля
            model.addAttribute("successMessage", "Пароль успешно изменен");
            return "orderManager/personal-area";
        }

        // Если пользователя не найдено, вернуть сообщение об ошибке
        model.addAttribute("errorMessage", "Пользователь не найден");
        return "orderManager/personal-area";
    }

    @GetMapping("/favorites")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String favorites(Model model, Principal principal) {
        String username = principal.getName();
        Optional<MyUser> user = userService.findByUsername(username);
        List<Favorite> favorites = favoriteService.getFavoritesByUsername(username);
        model.addAttribute("favorites", favorites);

        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/favorites";
    }

    @PostMapping("/addToFavorites")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String addToFavorites(@RequestParam("bicycleId") Long bicycleId, Principal principal) {
        String username = principal.getName();
        MyUser user = userService.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found"));
        Bicycle bicycle = bicycleService.getBicycleById(bicycleId);
        Favorite favorite = new Favorite();
        favorite.setUser(user);
        favorite.setBicycle(bicycle);
        favoriteService.addToFavorites(favorite); // Добавление в избранное
        return "redirect:/orderManager/favorites";
    }

    @PostMapping("/removeFromFavorites")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String removeFromFavorites(@RequestParam("favoriteId") Long favoriteId) {
        favoriteService.removeFromFavorites(favoriteId); // Удаление из избранного
        return "redirect:/orderManager/favorites";
    }


    // Обновленный метод для загрузки изображения
    @PostMapping("/upload-avatar")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String uploadAvatar(@RequestParam("avatar") MultipartFile file, RedirectAttributes redirectAttributes) {
        if (file.isEmpty()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Выберите файл для загрузки");
//            return "redirect:/users/personal-area";
            return "orderManager/personal-area";
        }
        try {
            byte[] imageData = file.getBytes();
            MyUser currentUser = userService.getCurrentUser();

            if (currentUser != null) {
                currentUser.setImageData(imageData);
                userService.updateUserWithImage(currentUser); // Используем метод обновления пользователя с изображением

                redirectAttributes.addFlashAttribute("successMessage", "Аватар успешно загружен");
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Не удалось получить информацию о текущем пользователе");
            }
        } catch (IOException e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("errorMessage", "Ошибка загрузки файла");
        } catch (Exception e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("errorMessage", "Произошла ошибка при сохранении изображения");
        }
//        return "redirect:/users/personal-area";
        return "orderManager/personal-area";
    }

    // личный кабинет
    @GetMapping("/personalArea")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String personalArea(Model model, Principal principal) {
        model.addAttribute("personalArea", "Личный кабинет");
        // Получаем текущего пользователя
        MyUser currentUser = userService.getCurrentUser();
        if (currentUser != null) {
            model.addAttribute("user", currentUser);
        }
        model.addAttribute("username", principal.getName());
        return "orderManager/personal-area";
    }

    @GetMapping("/personalArea/image/{userId}")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public ResponseEntity<byte[]> getUserImage(@PathVariable Long userId) {
        MyUser user = userService.getUserById(userId);
        if (user != null && user.getImageData() != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_JPEG);
            headers.setContentLength(user.getImageData().length);
            return new ResponseEntity<>(user.getImageData(), headers, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
        }
    }



}
