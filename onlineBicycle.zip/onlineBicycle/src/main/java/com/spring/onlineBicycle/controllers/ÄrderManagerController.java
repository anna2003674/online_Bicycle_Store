package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.models.BicycleFilter;
import com.spring.onlineBicycle.models.Purchase;
import com.spring.onlineBicycle.models.SliderImage;
import com.spring.onlineBicycle.services.BicycleService;
import com.spring.onlineBicycle.services.PurchaseService;
import com.spring.onlineBicycle.services.SliderImageService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/orderManager")
@AllArgsConstructor
public class ОrderManagerController {

    private final PurchaseService purchaseService;
    private final BicycleService bicycleService;
    private final SliderImageService sliderImageService;

    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String showHomePageAdm(Model model, Principal principal) {
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("sliderImages", sliderImages);
        model.addAttribute("title", "Главная страница сайта");
        model.addAttribute("username", principal.getName());
        return "orderManager/home";
    }

    @GetMapping("/catalog")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String orderManagerCatalog(Model model, Principal principal) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/cataloge";
    }

    @GetMapping("/orderList")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String orderList(Model model, Principal principal) {
        List<Purchase> orders = purchaseService.getAllOrders();
        model.addAttribute("orders", orders);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/orderList";
    }

    @GetMapping("/catalog/details")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String details(@RequestParam("id") Long id, Model model, Principal principal) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/bicycle-details";
    }

    // Отмена заказа
    @PostMapping("/orderList/cancel")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String cancelOrder(@RequestParam("orderId") Long orderId) {
        Purchase order = purchaseService.getOrderById(orderId);
        if (order != null) {
            order.setStatus("cancelled"); // установите статус заказа на "cancelled"
            purchaseService.updateOrder(order); // обновите заказ в базе данных
        }
        return "redirect:/orderManager/orderList"; // перенаправьте обратно к списку заказов
    }
    
    // подтверждение заказа
    @PostMapping("/orderList/confirm")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String confirmOrder(@RequestParam("orderId") Long orderId) {
        Purchase order = purchaseService.getOrderById(orderId);
        if (order != null) {
            order.setStatus("confirmed"); // установите статус заказа на "confirmed"
            purchaseService.updateOrder(order); // обновите заказ в базе данных
        }
        return "redirect:/orderManager/orderList"; // перенаправьте обратно к списку заказов
    }

    @GetMapping("/cataloge/{id}")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public ResponseEntity<byte[]> getBicycleImageById(@PathVariable("id") Long id) {
        Bicycle bicycle = bicycleService.getBicycleImageById(id);
        if (bicycle != null && bicycle.getImageData() != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_JPEG); // или MediaType.IMAGE_PNG, в зависимости от формата изображения
            return new ResponseEntity<>(bicycle.getImageData(), headers, HttpStatus.OK);
        } else {
            // Здесь вы можете вернуть пустое изображение или сообщение об ошибке, в зависимости от вашего случая
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/home/{id}")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public ResponseEntity<byte[]> getSliderImage(@PathVariable String id) {
        try {
            Long sliderId = Long.parseLong(id);
            SliderImage sliderImage = sliderImageService.getSliderImageById(sliderId);
            if (sliderImage != null && sliderImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(sliderImage.getImageData().length);
                return new ResponseEntity<>(sliderImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }


    // фильтр по всем полям
    @PostMapping("/catalog/filter")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalog(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicycles(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "orderManager/cataloge";
    }

    // фильтр по всем полям
    @GetMapping("/catalog/filter")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalogGet(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicycles(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/cataloge";
    }


    // фильтр по весу
    @PostMapping("/catalog/filterWeigh")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalogWeigh(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWeigh(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "orderManager/cataloge";
    }

    // фильтр по весу
    @GetMapping("/catalog/filterWeigh")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalogGetWeigh(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWeigh(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/cataloge";
    }


    // фильтр по бренду и количеству скоростей
    @PostMapping("/catalog/filterBrand")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalogBrand(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesBrands(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "orderManager/cataloge";
    }

    // фильтр по бренду и количеству скоростей
    @GetMapping("/catalog/filterBrand")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalogGetBrand(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesBrands(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/cataloge";
    }


    // фильтр по диаметру колес
    @PostMapping("/catalog/filterWheelDiameter")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalogWheelDiameter(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWheelDiameter(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "orderManager/cataloge";
    }

    // фильтр по диаметру колес
    @GetMapping("/catalog/filterWheelDiameter")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String filterBicyclesCatalogGetWheelDiameter(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWheelDiameter(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/cataloge";
    }


    // личный кабинет
    @GetMapping("/personalArea")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String personalArea(Model model, Principal principal) {
        model.addAttribute("personalArea", "Личный кабинет");
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "orderManager/personal-area";
    }





}
