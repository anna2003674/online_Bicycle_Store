package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.models.Purchase;
import com.spring.onlineBicycle.models.SliderImage;
import com.spring.onlineBicycle.services.BicycleService;
import com.spring.onlineBicycle.services.PurchaseService;
import com.spring.onlineBicycle.services.SliderImageService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/orderManager")
@AllArgsConstructor
public class ОrderManagerController {

    private final PurchaseService purchaseService;
    private final BicycleService bicycleService;
    private final SliderImageService sliderImageService;

    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String showHomePageAdm(Model model) {
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("sliderImages", sliderImages);
        model.addAttribute("title", "Главная страница сайта");
        return "orderManager/home";
    }

    @GetMapping("/catalog")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String orderManagerCatalog(Model model) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        return "orderManager/cataloge";
    }

    @GetMapping("/orderList")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String orderList(Model model) {
        List<Purchase> orders = purchaseService.getAllOrders();
        model.addAttribute("orders", orders);
        return "orderManager/orderList";
    }

    @GetMapping("/catalog/details")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String details(@RequestParam("id") Long id, Model model) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        return "orderManager/bicycle-details";
    }

    // Отмена заказа
    @PostMapping("/orderList/cancel")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String cancelOrder(@RequestParam("orderId") Long orderId) {
        Purchase order = purchaseService.getOrderById(orderId);
        if (order != null) {
            order.setStatus("cancelled"); // установите статус заказа на "cancelled"
            purchaseService.updateOrder(order); // обновите заказ в базе данных
        }
        return "redirect:/orderManager/orderList"; // перенаправьте обратно к списку заказов
    }
    
    // подтверждение заказа
    @PostMapping("/orderList/confirm")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public String confirmOrder(@RequestParam("orderId") Long orderId) {
        Purchase order = purchaseService.getOrderById(orderId);
        if (order != null) {
            order.setStatus("confirmed"); // установите статус заказа на "confirmed"
            purchaseService.updateOrder(order); // обновите заказ в базе данных
        }
        return "redirect:/orderManager/orderList"; // перенаправьте обратно к списку заказов
    }

    @GetMapping("/cataloge/{id}")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public ResponseEntity<byte[]> getBicycleImageById(@PathVariable("id") Long id) {
        Bicycle bicycle = bicycleService.getBicycleImageById(id);
        if (bicycle != null && bicycle.getImageData() != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_JPEG); // или MediaType.IMAGE_PNG, в зависимости от формата изображения
            return new ResponseEntity<>(bicycle.getImageData(), headers, HttpStatus.OK);
        } else {
            // Здесь вы можете вернуть пустое изображение или сообщение об ошибке, в зависимости от вашего случая
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/home/{id}")
    @PreAuthorize("hasAuthority('ROLE_ORDERMANAGER')")
    public ResponseEntity<byte[]> getSliderImage(@PathVariable String id) {
        try {
            Long sliderId = Long.parseLong(id);
            SliderImage sliderImage = sliderImageService.getSliderImageById(sliderId);
            if (sliderImage != null && sliderImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(sliderImage.getImageData().length);
                return new ResponseEntity<>(sliderImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }


}
