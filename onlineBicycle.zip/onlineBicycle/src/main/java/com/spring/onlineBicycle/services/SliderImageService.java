package com.spring.onlineBicycle.services;

import com.spring.onlineBicycle.models.SliderImage;
import com.spring.onlineBicycle.repositories.SliderImageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SliderImageService {

    private final SliderImageRepository sliderImageRepository;

    @Autowired
    public SliderImageService(SliderImageRepository sliderImageRepository) {
        this.sliderImageRepository = sliderImageRepository;
    }

    public void saveSliderImage(byte[] imageData) {
        SliderImage sliderImage = new SliderImage();
        sliderImage.setImageData(imageData);
        sliderImageRepository.save(sliderImage);
    }

    public List<SliderImage> getAllSliderImages() {
        return sliderImageRepository.findAll();
    }

    public SliderImage getSliderImageById(Long id) {
        return sliderImageRepository.findById(id).orElse(null);
    }

}
