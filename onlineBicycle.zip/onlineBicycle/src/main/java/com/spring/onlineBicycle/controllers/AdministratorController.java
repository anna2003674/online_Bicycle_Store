package com.spring.onlineBicycle.controllers;

import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/administrator")
@AllArgsConstructor
public class AdministratorController {

    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String showHomePageAdm() {
        System.out.println("Main controller");
        return "administrator/homeAdm";
    }

    @GetMapping("/add")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String usersAdd() {
        return "administrator/usersAdd";
    }


    @GetMapping("/contact")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String contactAdministrator(){
        return "administrator/contactAdm";
    }

    @GetMapping("/deliveryPayment")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String deliveryPaymentAdministrator(){
        return "administrator/deliveryPaymentAdm";
    }

}

