package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.MyUser;
import com.spring.onlineBicycle.services.MyUserService;
import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/administrator")
@AllArgsConstructor
public class AdministratorController {

    private final MyUserService userService;

    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String showHomePageAdm() {
        return "administrator/homeAdm";
    }


    @GetMapping("/contact")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String contactAdministrator() {
        return "administrator/contactAdm";
    }

    @GetMapping("/deliveryPayment")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String deliveryPaymentAdministrator() {
        return "administrator/deliveryPaymentAdm";
    }

    @GetMapping("/users")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String showUsers(Model model) {
        List<MyUser> users = userService.getAllUsers();
        model.addAttribute("users", users);
        return "administrator/usersAdd";
    }

    @DeleteMapping("/users/{id}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return "redirect:/administrator/users";
    }

    @GetMapping("/users/addUsersPage")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String addUsersPage() {
        return "administrator/adduserspage";
    }

    @PostMapping("/users")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String addUser(@ModelAttribute("newUser") MyUser newUser) {
        userService.saveUser(newUser);
        return "redirect:/administrator/users";
    }

    @GetMapping("/users/edit/{id}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String editUser(@PathVariable Long id, Model model) {
        MyUser user = userService.getUserById(id);
        model.addAttribute("user", user);
        model.addAttribute("name", user.getName()); // Установить значение для имени пользователя
        model.addAttribute("password", user.getPassword()); // Установить значение для пароля
        model.addAttribute("roles", user.getRoles()); // Установить значение для ролей
        return "administrator/updateuser";
    }

    @PostMapping("/users/edit")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String updateUser(@ModelAttribute MyUser updatedUser) {
        userService.saveUser(updatedUser);
        return "redirect:/administrator/users";
    }

}

