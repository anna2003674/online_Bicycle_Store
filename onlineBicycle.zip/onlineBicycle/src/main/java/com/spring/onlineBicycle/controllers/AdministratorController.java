package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.DeliveryImage;
import com.spring.onlineBicycle.models.MyUser;
import com.spring.onlineBicycle.models.SliderImage;
import com.spring.onlineBicycle.services.DeliveryImageService;
import com.spring.onlineBicycle.services.MyUserService;
import com.spring.onlineBicycle.services.SliderImageService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/administrator")
@AllArgsConstructor
public class AdministratorController {

    private final MyUserService userService;
    private final DeliveryImageService deliveryImageService;
    private final SliderImageService sliderImageService;

    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String showHomePageAdm(Model model, Principal principal) {
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("sliderImages", sliderImages);
        model.addAttribute("title", "Главная страница сайта");
        model.addAttribute("username", principal.getName()); // Добавить имя пользователя в модель
        return "administrator/homeAdm";
    }

    @GetMapping("/contact")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String contactAdministrator(Model model, Principal principal) {
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName()); // Добавить имя пользователя в модель
        return "administrator/contactAdm";
    }

    @GetMapping("/deliveryPayment")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String deliveryPaymentAdministrator(Model model, Principal principal) {
        List<DeliveryImage> deliveryImages = deliveryImageService.getAllDeliveryImages();
        model.addAttribute("deliveryImages", deliveryImages); // добавить deliveryImages в модель
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "administrator/deliveryPaymentAdm";
    }

    @GetMapping("/users")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String showUsers(Model model, Principal principal) {
        List<MyUser> users = userService.getAllUsers();
        model.addAttribute("users", users);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "administrator/usersAdd";
    }

    @DeleteMapping("/users/{id}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String deleteUser(@PathVariable Long id, Model model, Principal principal) {
        userService.deleteUser(id);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "redirect:/administrator/users";
    }

    @GetMapping("/users/addUsersPage")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String addUsersPage(Model model, Principal principal) {
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "administrator/adduserspage";
    }

    @PostMapping("/users")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String addUser(@ModelAttribute("newUser") MyUser newUser, Model model, Principal principal) {
        userService.saveUser(newUser);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "redirect:/administrator/users";
    }

    @GetMapping("/users/edit/{id}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String editUser(@PathVariable Long id, Model model, Principal principal) {
        MyUser user = userService.getUserById(id);
        model.addAttribute("user", user);
        model.addAttribute("name", user.getName()); // Установить значение для имени пользователя
        model.addAttribute("password", user.getPassword()); // Установить значение для пароля
        model.addAttribute("roles", user.getRoles()); // Установить значение для ролей
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "administrator/updateuser";
    }

    @PostMapping("/users/edit")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String updateUser(@ModelAttribute MyUser updatedUser, Model model, Principal principal) {
        userService.saveUser(updatedUser);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "redirect:/administrator/users";
    }

    @GetMapping("/deliveryPayment/{id}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<byte[]> getDeliveryImage(@PathVariable String id) {
        try {
            Long deliveryId = Long.parseLong(id);
            DeliveryImage deliveryImage = deliveryImageService.getDeliveryImageById(deliveryId);
            if (deliveryImage != null && deliveryImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(deliveryImage.getImageData().length);
                return new ResponseEntity<>(deliveryImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }

    @GetMapping("/home/{id}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<byte[]> getSliderImage(@PathVariable String id) {
        try {
            Long sliderId = Long.parseLong(id);
            SliderImage sliderImage = sliderImageService.getSliderImageById(sliderId);
            if (sliderImage != null && sliderImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(sliderImage.getImageData().length);
                return new ResponseEntity<>(sliderImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }

    // личный кабинет
    @GetMapping("/personalArea")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String personalArea(Model model, Principal principal) {
        model.addAttribute("personalArea", "Личный кабинет");
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "administrator/personal-area";
    }



}

