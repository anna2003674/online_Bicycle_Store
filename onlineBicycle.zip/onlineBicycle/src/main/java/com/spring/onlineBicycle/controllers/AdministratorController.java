package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.DeliveryImage;
import com.spring.onlineBicycle.models.MyUser;
import com.spring.onlineBicycle.services.DeliveryImageService;
import com.spring.onlineBicycle.services.MyUserService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/administrator")
@AllArgsConstructor
public class AdministratorController {

    private final MyUserService userService;
    private final DeliveryImageService deliveryImageService;

    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String showHomePageAdm() {
        return "administrator/homeAdm";
    }

    @GetMapping("/contact")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String contactAdministrator() {
        return "administrator/contactAdm";
    }

    @GetMapping("/deliveryPayment")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String deliveryPaymentAdministrator(Model model) {
        List<DeliveryImage> deliveryImages = deliveryImageService.getAllDeliveryImages();
        model.addAttribute("deliveryImages", deliveryImages); // добавить deliveryImages в модель
        return "administrator/deliveryPaymentAdm";
    }

    @GetMapping("/users")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String showUsers(Model model) {
        List<MyUser> users = userService.getAllUsers();
        model.addAttribute("users", users);
        return "administrator/usersAdd";
    }

    @DeleteMapping("/users/{id}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return "redirect:/administrator/users";
    }

    @GetMapping("/users/addUsersPage")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String addUsersPage() {
        return "administrator/adduserspage";
    }

    @PostMapping("/users")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String addUser(@ModelAttribute("newUser") MyUser newUser) {
        userService.saveUser(newUser);
        return "redirect:/administrator/users";
    }

    @GetMapping("/users/edit/{id}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String editUser(@PathVariable Long id, Model model) {
        MyUser user = userService.getUserById(id);
        model.addAttribute("user", user);
        model.addAttribute("name", user.getName()); // Установить значение для имени пользователя
        model.addAttribute("password", user.getPassword()); // Установить значение для пароля
        model.addAttribute("roles", user.getRoles()); // Установить значение для ролей
        return "administrator/updateuser";
    }

    @PostMapping("/users/edit")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String updateUser(@ModelAttribute MyUser updatedUser) {
        userService.saveUser(updatedUser);
        return "redirect:/administrator/users";
    }

    @GetMapping("/deliveryPayment/{id}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<byte[]> getDeliveryImage(@PathVariable String id) {
        try {
            Long deliveryId = Long.parseLong(id);
            DeliveryImage deliveryImage = deliveryImageService.getDeliveryImageById(deliveryId);
            if (deliveryImage != null && deliveryImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(deliveryImage.getImageData().length);
                return new ResponseEntity<>(deliveryImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }

}

