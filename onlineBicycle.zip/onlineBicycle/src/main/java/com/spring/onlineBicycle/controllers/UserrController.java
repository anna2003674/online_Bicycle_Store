package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.*;
import com.spring.onlineBicycle.services.*;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/users")
@AllArgsConstructor
public class UserrController {
    private final BrandImageService brandImageService;
    private final BicycleService bicycleService;
    private final ShoppingCartService shoppingCartService;
    private final PurchaseService orderService;
    private final DeliveryImageService deliveryImageService;
    private final CompanyImageService companyImageService;
    private final SliderImageService sliderImageService;
    private final UserService userService;
    private final PasswordEncoder passwordEncoder;

    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String showHome(Model model, Principal principal) {
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("sliderImages", sliderImages);
        model.addAttribute("title", "Главная страница сайта");
        model.addAttribute("username", principal.getName());
        return "user/home";
    }

    @GetMapping("/about")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String about(Model model, Principal principal) {
        List<CompanyImage> companyImages = companyImageService.getAllCompanyImages();
        model.addAttribute("companyImages", companyImages);
        model.addAttribute("title", "О нас");
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/about";
    }

    @GetMapping("/brands")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String brands(Model model, Principal principal) {
        List<BrandImage> brandImages = brandImageService.getAllBrandImages();
        model.addAttribute("brandImages", brandImages);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/brands";
    }

    @GetMapping("/brands/{id}")
    public ResponseEntity<byte[]> getBrandImage(@PathVariable String id) {
        try {
            Long brandId = Long.parseLong(id);
            BrandImage brandImage = brandImageService.getBrandImageById(brandId);
            if (brandImage != null && brandImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(brandImage.getImageData().length);
                return new ResponseEntity<>(brandImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }

    @GetMapping("/contact")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String contact(Model model, Principal principal) {
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/contact";
    }

    @GetMapping("/deliveryPayment")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String deliveryPayment(Model model, Principal principal) {
        List<DeliveryImage> deliveryImages = deliveryImageService.getAllDeliveryImages();
        model.addAttribute("title", "Доставка и оплата");
        model.addAttribute("deliveryImages", deliveryImages); // добавить deliveryImages в модель
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/deliveryPayment";
    }

//    @GetMapping("/shoppingCart")
//    @PreAuthorize("hasAuthority('ROLE_USER')")
//    public String shoppingCart(Model model, Principal principal) {
//        List<ShoppingCartItem> cartItems = shoppingCartService.getCartItems();
//        model.addAttribute("cartItems", cartItems);
//        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
//        model.addAttribute("username", principal.getName());
//        return "user/shoppingCart";
//    }

    @GetMapping("/shoppingCart")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String shoppingCart(Model model, Principal principal) {
        List<ShoppingCartItem> cartItems = shoppingCartService.getCartItems();
        for (ShoppingCartItem item : cartItems) {
            // Получить изображение велосипеда по его ID
            Bicycle bicycle = bicycleService.getBicycleImageById(item.getBicycle().getId());
            // Установить изображение велосипеда в объект ShoppingCartItem
            item.getBicycle().setImageData(bicycle.getImageData());
        }
        model.addAttribute("cartItems", cartItems);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/shoppingCart";
    }
    
    @GetMapping("/catalog")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String clientCatalog(Model model, Principal principal) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/cataloge";
    }

    @PostMapping("/cataloge/search")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String searchBicyclesCataloge(@RequestParam("modell") String modell, Model model, Principal principal) {
        List<Bicycle> bicycles = bicycleService.searchBicyclesByModell(modell);
        model.addAttribute("bicycles", bicycles);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/cataloge";
    }

    @GetMapping("/cataloge/details")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String details(@RequestParam("id") Long id, Model model,Principal principal) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/bicycle-details";
    }

    @GetMapping("/cataloge/shoppingCart")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String catalogeShoppingCart(Model model, Principal principal) {
        model.addAttribute("shoppingCart", "shoppingCart");
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/cataloge";
    }

    @GetMapping("/cataloge/bicycleById")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String bicycleById(@RequestParam("id") Long id, Model model, Principal principal) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/page-bicyclebyid";
    }

    @PostMapping("/cataloge/bicycleById/addToCart")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String addToCart(@RequestParam("id") Long id) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        shoppingCartService.addToCart(bicycle);
        return "redirect:/users/shoppingCart";
    }

    @PostMapping("/shoppingCart/clear")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String clearCart() {
        shoppingCartService.clearCart();
        return "redirect:/users/shoppingCart";
    }

    @PostMapping("/shoppingCart/removeItem/{id}")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String removeItemFromCart(@PathVariable("id") Long bicycleId, @RequestParam("itemId") Long itemId) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        shoppingCartService.removeItemByBicycleIdAndItemIdAndUsername(bicycleId, itemId, username);
        return "redirect:/users/shoppingCart";
    }

    @GetMapping("/cataloge/orderForm")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String showOrderForm(@RequestParam("id") Long id, Model model, Principal principal) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/order-form";
    }

    @PostMapping("/cataloge/placeOrder")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String placeOrder(@RequestParam("id") Long id, @RequestParam("name") String name, @RequestParam("address") String address, @RequestParam("phone") String phone) {
        // Получить информацию о велосипеде по его идентификатору
        Bicycle bicycle = bicycleService.getBicycleById(id);
        // Создать новый заказ
        Purchase order = new Purchase();
        order.setBicycle(bicycle);
        order.setCustomerName(name);
        order.setDeliveryAddress(address);
        order.setPhoneNumber(phone);
        // Сохранить заказ в базе данных
        orderService.createOrder(order);
        // Перенаправить пользователя обратно в каталог
        return "redirect:/users/orders";
    }

    @GetMapping("/orders")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String orders(Model model, Principal principal) {
        // Получить текущего пользователя
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        // Получить список заказов для текущего пользователя
        List<Purchase> orders = orderService.getOrdersByUsername(username);
        // Передать список заказов в модель
        model.addAttribute("orders", orders);
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/orders";
    }

    @GetMapping("/cataloge/{id}")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<byte[]> getBicycleImageById(@PathVariable("id") Long id) {
        Bicycle bicycle = bicycleService.getBicycleImageById(id);
        if (bicycle != null && bicycle.getImageData() != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.IMAGE_JPEG); // или MediaType.IMAGE_PNG, в зависимости от формата изображения
            return new ResponseEntity<>(bicycle.getImageData(), headers, HttpStatus.OK);
        } else {
            // Здесь вы можете вернуть пустое изображение или сообщение об ошибке, в зависимости от вашего случая
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/deliveryPayment/{id}")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<byte[]> getDeliveryImage(@PathVariable String id) {
        try {
            Long deliveryId = Long.parseLong(id);
            DeliveryImage deliveryImage = deliveryImageService.getDeliveryImageById(deliveryId);
            if (deliveryImage != null && deliveryImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(deliveryImage.getImageData().length);
                return new ResponseEntity<>(deliveryImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }

    @GetMapping("/about/{id}")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<byte[]> getCompanyImage(@PathVariable String id) {
        try {
            Long companyId = Long.parseLong(id);
            CompanyImage companyImage = companyImageService.getCompanyImageById(companyId);
            if (companyImage != null && companyImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(companyImage.getImageData().length);
                return new ResponseEntity<>(companyImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }

    @GetMapping("/home/{id}")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<byte[]> getSliderImage(@PathVariable String id) {
        try {
            Long sliderId = Long.parseLong(id);
            SliderImage sliderImage = sliderImageService.getSliderImageById(sliderId);
            if (sliderImage != null && sliderImage.getImageData() != null) {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.IMAGE_JPEG);
                headers.setContentLength(sliderImage.getImageData().length);
                return new ResponseEntity<>(sliderImage.getImageData(), headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Изображение не найдено
            }
        } catch (NumberFormatException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); // Некорректный формат ID
        }
    }


    // фильтр по всем полям
    @PostMapping("/catalog/filter")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String filterBicyclesCatalog(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicycles(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "user/cataloge";
    }

    // фильтр по всем полям
    @GetMapping("/catalog/filter")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String filterBicyclesCatalogGet(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicycles(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/cataloge";
    }


    // фильтр по весу
    @PostMapping("/catalog/filterWeigh")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String filterBicyclesCatalogWeigh(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWeigh(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "user/cataloge";
    }

    // фильтр по весу
    @GetMapping("/catalog/filterWeigh")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String filterBicyclesCatalogGetWeigh(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWeigh(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/cataloge";
    }


    // фильтр по бренду и количеству скоростей
    @PostMapping("/catalog/filterBrand")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String filterBicyclesCatalogBrand(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesBrands(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "user/cataloge";
    }

    // фильтр по бренду и количеству скоростей
    @GetMapping("/catalog/filterBrand")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String filterBicyclesCatalogGetBrand(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesBrands(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/cataloge";
    }


    // фильтр по диаметру колес
    @PostMapping("/catalog/filterWheelDiameter")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String filterBicyclesCatalogWheelDiameter(@ModelAttribute BicycleFilter filter, Model model) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWheelDiameter(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        return "user/cataloge";
    }

    // фильтр по диаметру колес
    @GetMapping("/catalog/filterWheelDiameter")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String filterBicyclesCatalogGetWheelDiameter(@ModelAttribute BicycleFilter filter, Model model, Principal principal) {
        List<Bicycle> filteredBicycles = bicycleService.filterBicyclesWheelDiameter(filter);
        model.addAttribute("bicycles", filteredBicycles);
        model.addAttribute("filter", filter); // Сохранение значений фильтра
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/cataloge";
    }

    // личный кабинет
    @GetMapping("/personalArea")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String personalArea(Model model, Principal principal) {
        model.addAttribute("personalArea", "Личный кабинет");
        List<SliderImage> sliderImages = sliderImageService.getAllSliderImages();
        model.addAttribute("username", principal.getName());
        return "user/personal-area";
    }


    @PostMapping("/change-password")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String changePassword(@RequestParam("currentPassword") String currentPassword,
                                 @RequestParam("newPassword") String newPassword,
                                 @RequestParam("confirmPassword") String confirmPassword,
                                 Principal principal,
                                 Model model) {
        // Получить имя текущего пользователя
        String username = principal.getName();

        // Получить информацию о текущем пользователе
        Optional<MyUser> userOptional = userService.findByUsername(username);
        if (userOptional.isPresent()) {
            MyUser user = userOptional.get();
            // Проверить, соответствует ли текущий пароль введенному пользователем
            if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
                // Если текущий пароль не совпадает, вернуть сообщение об ошибке
                model.addAttribute("errorMessage", "Текущий пароль введен неверно");
                return "user/personal-area";
            }

            // Проверить, совпадают ли новый пароль и его подтверждение
            if (!newPassword.equals(confirmPassword)) {
                // Если новый пароль и его подтверждение не совпадают, вернуть сообщение об ошибке
                model.addAttribute("errorMessage", "Новый пароль и его подтверждение не совпадают");
                return "user/personal-area";
            }

            // Обновить пароль пользователя
            user.setPassword(passwordEncoder.encode(newPassword));
            userService.saveUser2(user);

            // Вернуть пользователя на страницу личного кабинета с сообщением об успешном изменении пароля
            model.addAttribute("successMessage", "Пароль успешно изменен");
            return "user/personal-area";
        }

        // Если пользователя не найдено, вернуть сообщение об ошибке
        model.addAttribute("errorMessage", "Пользователь не найден");
        return "user/personal-area";
    }







}
