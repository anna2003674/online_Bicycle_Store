package com.spring.onlineBicycle.controllers;
import com.spring.onlineBicycle.models.Bicycle;
//import com.spring.onlineBicycle.models.ShoppingCart;
import com.spring.onlineBicycle.models.ShoppingCartItem;
import com.spring.onlineBicycle.services.BicycleService;
import com.spring.onlineBicycle.services.ShoppingCartService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.List;

@Controller
@RequestMapping("/users")
@AllArgsConstructor
public class UserrController {

    private final BicycleService bicycleService;


    private final ShoppingCartService shoppingCartService;




    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String showHome() {
        return "user/home";
    }

    @GetMapping("/about")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String about() {
        return "user/about";
    }

    @GetMapping("/brands")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String brands() {
        return "user/brands";
    }

    @GetMapping("/contact")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String contact() {
        return "user/contact";
    }

    @GetMapping("/deliveryPayment")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String deliveryPayment() {
        return "user/deliveryPayment";
    }


    // корзина
//    @GetMapping("/shoppingCart")
//    @PreAuthorize("hasAuthority('ROLE_USER')")
//    public String shoppingCart(Model model) {
//        model.addAttribute("shoppingCart", "Корзина");
//        return "user/shoppingCart";
//    }

    @GetMapping("/shoppingCart")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String shoppingCart(Model model) {
        List<ShoppingCartItem> cartItems = shoppingCartService.getCartItems();
        model.addAttribute("cartItems", cartItems);
        return "user/shoppingCart";
    }



    // виден каталог велосипедов
    @GetMapping("/catalog")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String clientCatalog(Model model) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        return "user/cataloge";
    }


    // поиск на странице cataloge
    @PostMapping("/cataloge/search")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String searchBicyclesCataloge(@RequestParam("modell") String modell, Model model) {
        List<Bicycle> bicycles = bicycleService.searchBicyclesByModell(modell);
        model.addAttribute("bicycles", bicycles);
        return "user/cataloge";
    }


    // детали велосипеда
    @GetMapping("/cataloge/details")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String details(@RequestParam("id") Long id, Model model) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        return "user/bicycle-details";
    }


    // переход из каталога в корзину
    @GetMapping("/cataloge/shoppingCart")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String catalogeShoppingCart(Model model) {
        model.addAttribute("shoppingCart", "shoppingCart");
        return "user/cataloge";
    }


    @GetMapping("/cataloge/bicycleById")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String bicycleById(@RequestParam("id") Long id, Model model) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        return "user/page-bicyclebyid";
    }



    @PostMapping("/cataloge/bicycleById/addToCart")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String addToCart(@RequestParam("id") Long id) {
        // Получение информации о товаре по его id из базы данных
        Bicycle bicycle = bicycleService.getBicycleById(id);

        // Сохранение товара в корзине
        shoppingCartService.addToCart(bicycle);

        // Перенаправление на страницу корзины
        return "redirect:/users/shoppingCart";
    }





}
