package com.spring.onlineBicycle.controllers;

import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/users")
@AllArgsConstructor
public class UserrController {


    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String showHome() {
        return "user/home";
    }

    @GetMapping("/catalog")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String cataloge() {
        return "user/cataloge";
    }

    @GetMapping("/about")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String about() {
        return "user/about";
    }

    @GetMapping("/brands")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String brands() {
        return "user/brands";
    }

    @GetMapping("/contact")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String contact() {
        return "user/contact";
    }

    @GetMapping("/deliveryPayment")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String deliveryPayment() {
        return "user/deliveryPayment";
    }

    @GetMapping("/shoppingCart")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String shoppingCart(Model model) {
        model.addAttribute("shoppingCart","корзина");
        return "user/shoppingCart";
    }


}
