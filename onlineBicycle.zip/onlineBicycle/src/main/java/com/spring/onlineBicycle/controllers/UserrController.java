package com.spring.onlineBicycle.controllers;

import com.spring.onlineBicycle.models.Bicycle;
import com.spring.onlineBicycle.models.ShoppingCartItem;
import com.spring.onlineBicycle.services.BicycleService;
import com.spring.onlineBicycle.services.ShoppingCartService;
import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/users")
@AllArgsConstructor
public class UserrController {

    private final BicycleService bicycleService;

    private final ShoppingCartService shoppingCartService;

    @GetMapping("/home")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String showHome() {
        return "user/home";
    }

    @GetMapping("/about")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String about() {
        return "user/about";
    }

    @GetMapping("/brands")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String brands() {
        return "user/brands";
    }

    @GetMapping("/contact")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String contact() {
        return "user/contact";
    }
    @GetMapping("/orders")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String orders() {
        return "user/orders";
    }

    @GetMapping("/deliveryPayment")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String deliveryPayment() {
        return "user/deliveryPayment";
    }

    @GetMapping("/shoppingCart")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String shoppingCart(Model model) {
        List<ShoppingCartItem> cartItems = shoppingCartService.getCartItems();
        model.addAttribute("cartItems", cartItems);
        return "user/shoppingCart";
    }

    @GetMapping("/catalog")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String clientCatalog(Model model) {
        List<Bicycle> bicycles = bicycleService.getAllBicycles();
        model.addAttribute("bicycles", bicycles);
        return "user/cataloge";
    }

    @PostMapping("/cataloge/search")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String searchBicyclesCataloge(@RequestParam("modell") String modell, Model model) {
        List<Bicycle> bicycles = bicycleService.searchBicyclesByModell(modell);
        model.addAttribute("bicycles", bicycles);
        return "user/cataloge";
    }

    @GetMapping("/cataloge/details")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String details(@RequestParam("id") Long id, Model model) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        return "user/bicycle-details";
    }

    @GetMapping("/cataloge/shoppingCart")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String catalogeShoppingCart(Model model) {
        model.addAttribute("shoppingCart", "shoppingCart");
        return "user/cataloge";
    }

    @GetMapping("/cataloge/bicycleById")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String bicycleById(@RequestParam("id") Long id, Model model) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        model.addAttribute("bicycle", bicycle);
        return "user/page-bicyclebyid";
    }

    @PostMapping("/cataloge/bicycleById/addToCart")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String addToCart(@RequestParam("id") Long id) {
        Bicycle bicycle = bicycleService.getBicycleById(id);
        shoppingCartService.addToCart(bicycle);
        return "redirect:/users/shoppingCart";
    }

    @PostMapping("/shoppingCart/clear")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String clearCart() {
        shoppingCartService.clearCart();
        return "redirect:/users/shoppingCart";
    }

    @PostMapping("/shoppingCart/removeItem/{id}")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String removeItemFromCart(@PathVariable("id") Long bicycleId, @RequestParam("itemId") Long itemId) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        shoppingCartService.removeItemByBicycleIdAndItemIdAndUsername(bicycleId, itemId, username);
        return "redirect:/users/shoppingCart";
    }

}
